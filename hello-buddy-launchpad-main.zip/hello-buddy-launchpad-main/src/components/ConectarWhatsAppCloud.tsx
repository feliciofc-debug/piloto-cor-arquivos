// Fase 1.2 — Botão de Embedded Signup do WhatsApp Cloud API
// Abre o Facebook Login for Business com config_id, escuta a mensagem
// 'WA_EMBEDDED_SIGNUP' (que traz waba_id + phone_number_id) e chama
// a edge function whatsapp-embedded-signup-callback com o code.

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, CheckCircle2, AlertCircle, MessageCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

// APP_ID e config_id são carregados em runtime via edge function pública
// `get-meta-public-config` (fonte única = secrets do projeto).

declare global {
  interface Window {
    FB: any;
    fbAsyncInit: any;
  }
}

interface ConfigRow {
  display_phone: string | null;
  business_name: string | null;
  is_active: boolean | null;
  token_expires_at: string | null;
  alert_status: string | null;
}

export default function ConectarWhatsAppCloud() {
  const [config, setConfig] = useState<ConfigRow | null>(null);
  const [loading, setLoading] = useState(true);
  const [connecting, setConnecting] = useState(false);
  const [pin, setPin] = useState("000000");
  const [sdkStatus, setSdkStatus] = useState<"loading" | "ready" | "blocked">("loading");
  const [metaCfg, setMetaCfg] = useState<{ app_id: string | null; embedded_config_id: string | null } | null>(null);

  // 1) Carrega config pública do Meta (APP_ID + embedded_config_id) e SDK do Facebook
  useEffect(() => {
    let timeout: ReturnType<typeof setTimeout>;
    (async () => {
      const { data } = await supabase.functions.invoke("get-meta-public-config", { method: "GET" });
      setMetaCfg(data ?? { app_id: null, embedded_config_id: null });
      if (!data?.app_id) { setSdkStatus("blocked"); return; }
      if (window.FB) { setSdkStatus("ready"); return; }
      window.fbAsyncInit = function () {
        window.FB.init({
          appId: data.app_id,
          cookie: true,
          xfbml: true,
          version: "v25.0",
        });
        setSdkStatus("ready");
      };
      const s = document.createElement("script");
      s.src = "https://connect.facebook.net/en_US/sdk.js";
      s.async = true;
      s.defer = true;
      s.onerror = () => setSdkStatus("blocked");
      document.body.appendChild(s);
      // Bloqueadores de anúncio costumam silenciar o script sem disparar onerror
      timeout = setTimeout(() => {
        setSdkStatus((prev) => (prev === "ready" ? prev : "blocked"));
      }, 8000);
    })();
    return () => clearTimeout(timeout);
  }, []);


  // 2) Lê config atual
  useEffect(() => {
    (async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) { setLoading(false); return; }
      const { data } = await supabase
        .from("whatsapp_config")
        .select("display_phone, business_name, is_active, token_expires_at, alert_status")
        .eq("user_id", u.user.id)
        .maybeSingle();
      setConfig(data);
      setLoading(false);
    })();
  }, []);

  // 3) Escuta mensagem do Embedded Signup
  useEffect(() => {
    const handler = (event: MessageEvent) => {
      if (event.origin !== "https://www.facebook.com" && event.origin !== "https://web.facebook.com") return;
      try {
        const data = typeof event.data === "string" ? JSON.parse(event.data) : event.data;
        if (data?.type !== "WA_EMBEDDED_SIGNUP") return;
        if (data.event === "FINISH" || data.event === "FINISH_ONLY_WABA") {
          // data.data = { waba_id, phone_number_id, business_id, ... }
          (window as any).__waEmbeddedPayload = data.data;
        }
        if (data.event === "CANCEL" || data.event === "ERROR") {
          (window as any).__waEmbeddedCancel = data.data ?? { reason: data.event };
        }
      } catch (_) { /* ignore */ }
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  const handleConnect = () => {
    if (sdkStatus === "blocked" || !window.FB) {
      toast.error(
        "Não foi possível carregar o login do Facebook. Desative o bloqueador de anúncios/rastreamento (ou use uma aba sem extensões) e tente novamente.",
      );
      return;
    }
    if (sdkStatus === "loading") { toast.info("SDK do Facebook ainda carregando…"); return; }
    if (!metaCfg?.embedded_config_id) {
      toast.error("WHATSAPP_EMBEDDED_CONFIG_ID não configurado nos secrets");
      return;
    }
    if (!/^\d{6}$/.test(pin)) { toast.error("O PIN deve ter exatamente 6 dígitos"); return; }

    setConnecting(true);
    // IMPORTANTE: o SDK do Facebook rejeita callbacks async
    // ("Expression is of type asyncfunction, not function").
    // O callback precisa ser síncrono e disparar o trabalho assíncrono internamente.
    window.FB.login(
      (response: any) => {
        void (async () => {
        try {
          const code = response?.authResponse?.code;
          if (!code) {
            toast.error("Login do Facebook cancelado — nenhuma permissão foi concedida.");
            return;
          }
          // O postMessage WA_EMBEDDED_SIGNUP pode chegar depois do callback
          // (ou nem chegar). Esperamos até 8s e seguimos mesmo sem ele:
          // a edge function resolve waba_id/phone_number_id pelo token.
          let payload = (window as any).__waEmbeddedPayload;
          for (let i = 0; i < 16 && !payload?.waba_id; i++) {
            if ((window as any).__waEmbeddedCancel) break;
            await new Promise((r) => setTimeout(r, 500));
            payload = (window as any).__waEmbeddedPayload;
          }
          const { data: { session } } = await supabase.auth.getSession();
          const { data, error } = await supabase.functions.invoke(
            "whatsapp-embedded-signup-callback",
            {
              body: {
                code,
                waba_id: payload?.waba_id ?? null,
                phone_number_id: payload?.phone_number_id ?? null,
                pin,
              },
              headers: { Authorization: `Bearer ${session?.access_token}` },
            },
          );
          if (error || !data?.success) {
            console.error("[embedded-signup] falha", { error, data });
            const raw = data?.error;
            const detalhe =
              typeof raw === "string" ? raw
              : raw?.error?.message || raw?.message
              || (raw ? JSON.stringify(raw) : null)
              || error?.message
              || "erro desconhecido";
            toast.error(`Falha ao conectar${data?.step ? ` (${data.step})` : ""}: ${detalhe}`, {
              duration: 15000,
            });
            return;
          }


          toast.success(`Conectado: ${data.display_phone || ""}`);
          if (data.register_warning) {
            toast.warning("Número conectado, mas o registro na Cloud API retornou aviso — se o número já tinha PIN de 2FA, informe o PIN correto e reconecte.");
          }
          // recarrega config
          const { data: u } = await supabase.auth.getUser();
          const { data: cfg } = await supabase
            .from("whatsapp_config")
            .select("display_phone, business_name, is_active, token_expires_at, alert_status")
            .eq("user_id", u.user!.id)
            .maybeSingle();
          setConfig(cfg);
        } finally {
          setConnecting(false);
          (window as any).__waEmbeddedPayload = null;
          (window as any).__waEmbeddedCancel = null;
    (window as any).__waEmbeddedCancel = null;
        }
        })();
      },
      {
        config_id: metaCfg.embedded_config_id,
        response_type: "code",
        override_default_response_type: true,
        extras: { setup: {}, featureType: "", sessionInfoVersion: "3" },
      },
    );
  };

  const handleDisconnect = async () => {
    const { data: u } = await supabase.auth.getUser();
    if (!u.user) return;
    await supabase.from("whatsapp_config")
      .update({ is_active: false, alert_status: "none" })
      .eq("user_id", u.user.id);
    setConfig((c) => c ? { ...c, is_active: false } : c);
    toast.success("Desconectado");
  };

  if (loading) return <div className="p-6"><Loader2 className="animate-spin" /></div>;

  const connected = !!config?.is_active;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageCircle className="h-5 w-5" /> WhatsApp Cloud API (Oficial)
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {connected ? (
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
              <span className="font-medium">{config?.business_name || "Conectado"}</span>
              <Badge variant="outline">{config?.display_phone}</Badge>
            </div>
            {config?.alert_status === "reconnect_soon" && (
              <div className="flex items-center gap-2 text-amber-700 text-sm">
                <AlertCircle className="h-4 w-4" /> Token próximo do vencimento — reconecte para garantir continuidade.
              </div>
            )}
            {config?.alert_status === "refresh_failed" && (
              <div className="flex items-center gap-2 text-red-700 text-sm">
                <AlertCircle className="h-4 w-4" /> Conexão expirada. Reconecte agora.
              </div>
            )}
            <Button variant="outline" onClick={handleDisconnect}>Desconectar</Button>
          </div>
        ) : (
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Conecte seu próprio número WhatsApp Business pela Meta — sem digitar tokens.
              A conta de negócio e a cobrança ficam no seu próprio cadastro do Meta.
            </p>
            <div className="space-y-1.5 max-w-[220px]">
              <Label htmlFor="wa-pin">PIN de 6 dígitos</Label>
              <Input
                id="wa-pin"
                inputMode="numeric"
                maxLength={6}
                value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 6))}
              />
              <p className="text-xs text-muted-foreground">
                Padrão 000000. Se o número já tem verificação em duas etapas, informe o PIN existente.
              </p>
            </div>
            {sdkStatus === "blocked" && (
              <div className="flex items-start gap-2 text-sm text-red-700">
                <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                <span>
                  O login do Facebook não carregou. Isso costuma ser bloqueador de anúncios/rastreamento
                  ou extensão de privacidade. Desative para este site e recarregue a página.
                </span>
              </div>
            )}
            <Button onClick={handleConnect} disabled={connecting}>
              {connecting ? <Loader2 className="animate-spin mr-2 h-4 w-4" /> : null}

              Conectar WhatsApp
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
