import { useState, useEffect, useRef } from "react";
import { QRCodeCanvas } from "qrcode.react";
import { useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft, MessageCircle, Users, Send, Smartphone, BookOpen, Megaphone, Loader2, Settings, CheckCircle2, ExternalLink, Shield, Bot, Inbox, PlugZap, Sparkles, Copy, Check, Link2, Download, QrCode } from "lucide-react";
import { toast } from "sonner";

interface WhatsAppConfig {
  id: string;
  phone_number_id: string | null;
  waba_id: string | null;
  access_token: string | null;
  display_phone: string | null;
  business_name: string | null;
  is_active: boolean;
  is_verified: boolean;
  last_verified_at: string | null;
}

function onlyDigits(phone: string | null | undefined): string {
  return (phone || "").replace(/\D/g, "");
}

function formatPhoneReadable(phone: string | null | undefined): string {
  const digits = onlyDigits(phone);
  if (digits.length === 13 && digits.startsWith("55")) {
    return `+55 (${digits.slice(2, 4)}) ${digits.slice(4, 9)}-${digits.slice(9)}`;
  }
  if (digits.length === 12 && digits.startsWith("55")) {
    return `+55 (${digits.slice(2, 4)}) ${digits.slice(4, 8)}-${digits.slice(8)}`;
  }
  if (digits.length === 11) {
    return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7)}`;
  }
  if (digits.length === 10) {
    return `(${digits.slice(0, 2)}) ${digits.slice(2, 6)}-${digits.slice(6)}`;
  }
  return phone || "";
}

export default function WhatsAppPainel() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ enviadas: 0, grupos: 0, campanhasAtivas: 0, conversasAtivas: 0 });
  const [agentActive, setAgentActive] = useState<boolean | null>(null);
  const [whatsappConfig, setWhatsappConfig] = useState<WhatsAppConfig | null>(null);
  const [showConfig, setShowConfig] = useState(false);
  const [saving, setSaving] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [linkPost, setLinkPost] = useState('');
  const [savingLinkPost, setSavingLinkPost] = useState(false);
  const [vozCopy, setVozCopy] = useState<'empresa' | 'pessoa'>('empresa');
  const [nomeAssinatura, setNomeAssinatura] = useState('');
  const [savingVoz, setSavingVoz] = useState(false);
  const qrWrapperRef = useRef<HTMLDivElement>(null);
  const [configForm, setConfigForm] = useState({
    phone_number_id: '',
    waba_id: '',
    access_token: '',
    display_phone: '',
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { count: enviadas } = await supabase
        .from("fila_atendimento_pj" as any)
        .select("*", { count: "exact", head: true })
        .eq("user_id", user.id)
        .eq("status", "enviado");

      const { count: campanhas } = await supabase
        .from("campanhas_recorrentes")
        .select("*", { count: "exact", head: true })
        .eq("user_id", user.id)
        .eq("ativa", true);

      const { count: conversasAtivas } = await supabase
        .from("whatsapp_cloud_conversations" as any)
        .select("*", { count: "exact", head: true })
        .eq("user_id", user.id);

      const { data: agentCfg } = await supabase
        .from("whatsapp_cloud_agent_config" as any)
        .select("is_active")
        .eq("user_id", user.id)
        .maybeSingle();
      setAgentActive(((agentCfg as any)?.is_active ?? null));

      setStats({
        enviadas: enviadas || 0,
        grupos: 0,
        campanhasAtivas: campanhas || 0,
        conversasAtivas: conversasAtivas || 0,
      });

      const { data: config } = await supabase
        .from('whatsapp_config' as any)
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (config) {
        setWhatsappConfig(config as any);
        setConfigForm({
          phone_number_id: (config as any).phone_number_id || '',
          waba_id: (config as any).waba_id || '',
          access_token: (config as any).access_token || '',
          display_phone: (config as any).display_phone || '',
        });
      }

      const { data: empresaCfg } = await supabase
        .from('empresa_config' as any)
        .select('link_post, voz_copy, nome_assinatura')
        .eq('user_id', user.id)
        .maybeSingle();
      setLinkPost(((empresaCfg as any)?.link_post) || '');
      setVozCopy(((empresaCfg as any)?.voz_copy === 'pessoa') ? 'pessoa' : 'empresa');
      setNomeAssinatura(((empresaCfg as any)?.nome_assinatura) || '');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveLinkPost = async () => {
    const valor = linkPost.trim();
    if (valor) {
      try {
        const u = new URL(valor);
        if (!['http:', 'https:'].includes(u.protocol)) throw new Error('protocolo');
      } catch {
        toast.error('Informe uma URL válida começando com https://');
        return;
      }
    }

    setSavingLinkPost(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from('empresa_config' as any)
        .upsert({ user_id: user.id, link_post: valor || null } as any, { onConflict: 'user_id' });

      if (error) throw error;
      setLinkPost(valor);
      toast.success(valor ? 'Link do post salvo' : 'Link do post removido');
    } catch (err: any) {
      console.error(err);
      toast.error(err?.message || 'Erro ao salvar o link');
    } finally {
      setSavingLinkPost(false);
    }
  };


  const handleSaveVozCopy = async () => {
    if (vozCopy === 'pessoa' && !nomeAssinatura.trim()) {
      toast.error('Informe o nome que vai assinar as legendas');
      return;
    }

    setSavingVoz(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from('empresa_config' as any)
        .upsert({
          user_id: user.id,
          voz_copy: vozCopy,
          nome_assinatura: vozCopy === 'pessoa' ? nomeAssinatura.trim() : null,
        } as any, { onConflict: 'user_id' });

      if (error) throw error;
      toast.success('Voz das legendas salva');
    } catch (err: any) {
      console.error(err);
      toast.error(err?.message || 'Erro ao salvar a voz das legendas');
    } finally {
      setSavingVoz(false);
    }
  };

  const handleSaveConfig = async () => {
    if (!configForm.phone_number_id || !configForm.access_token) {
      toast.error(t('whatsapp.required_fields'));
      return;
    }

    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase.functions.invoke('whatsapp-verify-connection', {
        body: {
          user_id: user.id,
          phone_number_id: configForm.phone_number_id.trim(),
          waba_id: configForm.waba_id.trim(),
          access_token: configForm.access_token.trim(),
          display_phone: configForm.display_phone.trim(),
        }
      });

      if (error) throw error;
      if (!data?.success) throw new Error(data?.error || 'Verification error');

      toast.success(`✅ ${t('whatsapp.connected_success')} ${data.business_name || data.verified_name || ''}`);
      setShowConfig(false);
      loadData();
    } catch (err: any) {
      toast.error(err.message || 'Error verifying connection');
    } finally {
      setSaving(false);
    }
  };

  const handleDisconnect = async () => {
    if (!confirm(t('whatsapp.disconnect_confirm'))) return;
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      await supabase
        .from('whatsapp_config' as any)
        .update({ is_active: false, updated_at: new Date().toISOString() } as any)
        .eq('user_id', user.id);

      toast.success(t('whatsapp.disconnected'));
      loadData();
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      <div>
        <Button onClick={() => navigate("/dashboard")} variant="ghost" className="mb-4">
          <ArrowLeft className="h-4 w-4 mr-2" /> {t('whatsapp.back')}
        </Button>
        <h1 className="text-2xl font-bold text-foreground">{t('whatsapp.title')}</h1>
        <p className="text-muted-foreground">{t('whatsapp.painel_subtitle')}</p>
      </div>

      {/* ============== ATENDIMENTO IA (OFICIAL) — PRODUTO PRINCIPAL ============== */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-green-600" />
          <h2 className="text-lg font-semibold text-foreground">Atendimento IA (Oficial)</h2>
          <Badge className="bg-green-600 text-white">Principal</Badge>
        </div>
        <p className="text-sm text-muted-foreground">
          Atendimento 1-a-1 automático no seu WhatsApp Business via API oficial da Meta.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card
            className="cursor-pointer hover:shadow-md transition-shadow border-green-200 dark:border-green-900"
            onClick={() => navigate("/atendimento-cloud")}
          >
            <CardContent className="p-5 flex items-start gap-3">
              <div className="p-2 rounded-lg bg-green-100 dark:bg-green-900/30">
                <Inbox className="h-6 w-6 text-green-600" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <p className="font-semibold text-foreground">Conversas</p>
                  <Badge variant="outline">{stats.conversasAtivas}</Badge>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Inbox do agente IA — atendimentos em andamento
                </p>
              </div>
            </CardContent>
          </Card>

          <Card
            className="cursor-pointer hover:shadow-md transition-shadow border-green-200 dark:border-green-900"
            onClick={() => navigate("/agente-whatsapp/config")}
          >
            <CardContent className="p-5 flex items-start gap-3">
              <div className="p-2 rounded-lg bg-green-100 dark:bg-green-900/30">
                <Bot className="h-6 w-6 text-green-600" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <p className="font-semibold text-foreground">Configurar Agente</p>
                  {agentActive === true && <Badge className="bg-green-600 text-white">Ativo</Badge>}
                  {agentActive === false && <Badge variant="secondary">Pausado</Badge>}
                  {agentActive === null && <Badge variant="outline">Não configurado</Badge>}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Persona, tom de voz, conhecimento e regras de handoff
                </p>
              </div>
            </CardContent>
          </Card>

          <Card
            className="cursor-pointer hover:shadow-md transition-shadow border-green-200 dark:border-green-900"
            onClick={() => {
              const el = document.getElementById("conectar-numero-card");
              el?.scrollIntoView({ behavior: "smooth", block: "start" });
            }}
          >
            <CardContent className="p-5 flex items-start gap-3">
              <div className="p-2 rounded-lg bg-green-100 dark:bg-green-900/30">
                <PlugZap className="h-6 w-6 text-green-600" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <p className="font-semibold text-foreground">Conectar Número</p>
                  {whatsappConfig?.is_active ? (
                    <Badge className="bg-green-600 text-white">Conectado</Badge>
                  ) : (
                    <Badge variant="outline">Pendente</Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {whatsappConfig?.display_phone || "Conecte seu WhatsApp Business oficial"}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <div id="conectar-numero-card" />


      {/* WhatsApp Cloud API Config Card */}
      <Card className="border-green-200 dark:border-green-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            {t('whatsapp.config_title')}
          </CardTitle>
          <CardDescription>
            {t('whatsapp.config_desc')}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {whatsappConfig?.is_active ? (
            <div className="space-y-4">
              <div className="flex items-center gap-4 p-4 bg-green-50 dark:bg-green-950/20 rounded-lg border border-green-200 dark:border-green-800">
                <CheckCircle2 className="h-10 w-10 text-green-500 flex-shrink-0" />
                <div className="flex-1">
                  <p className="font-semibold text-foreground">{whatsappConfig.business_name || 'WhatsApp Business'}</p>
                  <p className="text-sm text-muted-foreground">{whatsappConfig.display_phone}</p>
                </div>
                <Badge className="bg-green-500 text-white">{t('whatsapp.connected_badge')}</Badge>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => setShowConfig(true)}>
                  <Settings className="h-4 w-4 mr-1" /> {t('whatsapp.reconfigure')}
                </Button>
                <Button variant="destructive" size="sm" onClick={handleDisconnect}>
                  {t('whatsapp.disconnect')}
                </Button>
              </div>
            </div>
          ) : showConfig ? (
            <div className="space-y-6">
              <div className="bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                <p className="font-semibold text-sm mb-2">📋 {t('whatsapp.how_to_config')}</p>
                <ol className="text-sm text-muted-foreground space-y-1 list-decimal list-inside">
                  <li>
                    {t('whatsapp.config_step_1')}{' '}
                    <a href="https://business.facebook.com" target="_blank" rel="noopener noreferrer" className="text-primary underline inline-flex items-center gap-1">
                      business.facebook.com <ExternalLink className="h-3 w-3" />
                    </a>
                  </li>
                  <li>{t('whatsapp.config_step_2')}</li>
                  <li>{t('whatsapp.config_step_3')}</li>
                  <li>{t('whatsapp.config_step_4')}</li>
                  <li>{t('whatsapp.config_step_5')}</li>
                </ol>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>{t('whatsapp.phone_number_id')} *</Label>
                  <Input
                    placeholder="Ex: 123456789012345"
                    value={configForm.phone_number_id}
                    onChange={(e) => setConfigForm(f => ({ ...f, phone_number_id: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('whatsapp.waba_id')}</Label>
                  <Input
                    placeholder="Ex: 987654321098765"
                    value={configForm.waba_id}
                    onChange={(e) => setConfigForm(f => ({ ...f, waba_id: e.target.value }))}
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>{t('whatsapp.access_token')} *</Label>
                  <Input
                    type="password"
                    placeholder={t('whatsapp.paste_token')}
                    value={configForm.access_token}
                    onChange={(e) => setConfigForm(f => ({ ...f, access_token: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('whatsapp.whatsapp_number')}</Label>
                  <Input
                    placeholder="Ex: +55 21 99999-9999"
                    value={configForm.display_phone}
                    onChange={(e) => setConfigForm(f => ({ ...f, display_phone: e.target.value }))}
                  />
                </div>
              </div>

              <div className="flex gap-2">
                <Button onClick={handleSaveConfig} disabled={saving} className="gap-2">
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Shield className="h-4 w-4" />}
                  {saving ? t('whatsapp.verifying') : t('whatsapp.save_verify')}
                </Button>
                <Button variant="ghost" onClick={() => setShowConfig(false)}>{t('whatsapp.cancel')}</Button>
              </div>
            </div>
          ) : (
            <div className="text-center py-6 space-y-4">
              <Smartphone className="h-12 w-12 mx-auto text-muted-foreground" />
              <div>
                <p className="font-medium text-foreground">{t('whatsapp.not_connected_business')}</p>
                <p className="text-sm text-muted-foreground">{t('whatsapp.config_meta_desc')}</p>
              </div>
              <Button onClick={() => setShowConfig(true)} className="gap-2">
                <Settings className="h-4 w-4" />
                {t('whatsapp.config_business_btn')}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Link do WhatsApp do Agente */}
      <Card className="border-green-200 dark:border-green-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Link2 className="h-5 w-5" />
            Link do WhatsApp do Agente
          </CardTitle>
          <CardDescription>
            Link direto para iniciar uma conversa no WhatsApp do número conectado.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {whatsappConfig?.is_active && onlyDigits(whatsappConfig.display_phone) ? (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                <div className="flex-1 space-y-1">
                  <div className="flex items-center gap-2 text-foreground">
                    <Smartphone className="h-4 w-4 text-green-600" />
                    <span className="font-semibold">{formatPhoneReadable(whatsappConfig.display_phone)}</span>
                  </div>
                  <a
                    href={`https://wa.me/${onlyDigits(whatsappConfig.display_phone)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-primary hover:underline break-all"
                  >
                    https://wa.me/{onlyDigits(whatsappConfig.display_phone)}
                  </a>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      navigator.clipboard.writeText(`https://wa.me/${onlyDigits(whatsappConfig.display_phone)}`);
                      setCopiedLink(true);
                      setTimeout(() => setCopiedLink(false), 2000);
                    }}
                  >
                    {copiedLink ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                    {copiedLink ? "Copiado" : "Copiar link"}
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => window.open(`https://wa.me/${onlyDigits(whatsappConfig.display_phone)}`, "_blank", "noopener,noreferrer")}
                  >
                    <ExternalLink className="h-4 w-4 mr-1" />
                    Abrir conversa
                  </Button>
                </div>
              </div>

              <div className="flex flex-col md:flex-row items-center gap-6 p-4 bg-muted/30 rounded-lg">
                <div ref={qrWrapperRef} className="p-2 bg-white rounded-lg">
                  <QRCodeCanvas
                    value={`https://wa.me/${onlyDigits(whatsappConfig.display_phone)}`}
                    size={160}
                    level="M"
                    bgColor="#FFFFFF"
                    fgColor="#1a2332"
                    includeMargin={false}
                  />
                </div>
                <div className="flex-1 text-center md:text-left space-y-3">
                  <div className="flex items-center justify-center md:justify-start gap-2 text-foreground">
                    <QrCode className="h-4 w-4 text-primary" />
                    <p className="font-medium">QR Code do link</p>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Escaneie com a câmera do celular ou baixe o PNG para usar em cartões, flyers e redes sociais.
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const canvas = qrWrapperRef.current?.querySelector("canvas");
                      if (!canvas) return;
                      const url = canvas.toDataURL("image/png");
                      const a = document.createElement("a");
                      a.href = url;
                      a.download = `whatsapp-${onlyDigits(whatsappConfig.display_phone)}.png`;
                      a.click();
                    }}
                  >
                    <Download className="h-4 w-4 mr-1" />
                    Baixar QR Code (PNG)
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-6 space-y-4">
              <Smartphone className="h-12 w-12 mx-auto text-muted-foreground" />
              <div>
                <p className="font-medium text-foreground">Nenhum WhatsApp conectado</p>
                <p className="text-sm text-muted-foreground">
                  Conecte um número oficial para gerar o link direto do agente.
                </p>
              </div>
              <Button onClick={() => setShowConfig(true)} className="gap-2">
                <PlugZap className="h-4 w-4" />
                Conectar WhatsApp
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Link do post */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Link2 className="h-5 w-5" />
            Link do post
          </CardTitle>
          <CardDescription>
            Link colocado no <strong>início</strong> da legenda dos posts publicados (o Instagram corta a legenda em ~125 caracteres). Pode ser o WhatsApp do agente, seu site, catálogo ou landing page. Se ficar vazio, o post é publicado sem link.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-2">
            <Label htmlFor="link-post">URL</Label>
            <Input
              id="link-post"
              placeholder="https://..."
              value={linkPost}
              onChange={(e) => setLinkPost(e.target.value)}
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {onlyDigits(whatsappConfig?.display_phone) && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setLinkPost(`https://wa.me/${onlyDigits(whatsappConfig?.display_phone)}`)}
              >
                <MessageCircle className="h-4 w-4 mr-1" />
                Usar WhatsApp do agente
              </Button>
            )}
            <Button size="sm" onClick={handleSaveLinkPost} disabled={savingLinkPost}>
              {savingLinkPost ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Check className="h-4 w-4 mr-1" />}
              Salvar
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Voz das legendas */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageCircle className="h-5 w-5" />
            Voz das legendas
          </CardTitle>
          <CardDescription>
            Define como a IA escreve as copies: como empresa ("fale com a gente") ou como pessoa ("me chama", "eu te ajudo"), assinando com o seu nome.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-wrap gap-2">
            <Button
              variant={vozCopy === 'empresa' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setVozCopy('empresa')}
            >
              Empresa (nós)
            </Button>
            <Button
              variant={vozCopy === 'pessoa' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setVozCopy('pessoa')}
            >
              Pessoa (eu)
            </Button>
          </div>
          {vozCopy === 'pessoa' && (
            <div className="space-y-2">
              <Label htmlFor="nome-assinatura">Nome da assinatura</Label>
              <Input
                id="nome-assinatura"
                placeholder="Ex.: Paulo Canarim"
                value={nomeAssinatura}
                onChange={(e) => setNomeAssinatura(e.target.value)}
              />
            </div>
          )}
          <Button size="sm" onClick={handleSaveVozCopy} disabled={savingVoz}>
            {savingVoz ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Check className="h-4 w-4 mr-1" />}
            Salvar
          </Button>
        </CardContent>
      </Card>


      {/* Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <Send className="h-8 w-8 text-primary" />
            <div>
              <p className="text-2xl font-bold text-foreground">{stats.enviadas}</p>
              <p className="text-sm text-muted-foreground">{t('whatsapp.messages_sent')}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <Users className="h-8 w-8 text-primary" />
            <div>
              <p className="text-2xl font-bold text-foreground">{stats.grupos}</p>
              <p className="text-sm text-muted-foreground">{t('whatsapp.groups_configured')}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <MessageCircle className="h-8 w-8 text-primary" />
            <div>
              <p className="text-2xl font-bold text-foreground">{stats.campanhasAtivas}</p>
              <p className="text-sm text-muted-foreground">{t('whatsapp.active_campaigns')}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => navigate("/pj/listas-contatos")}>
          <CardContent className="p-6 flex items-center gap-4">
            <BookOpen className="h-8 w-8 text-primary" />
            <div>
              <p className="font-medium text-foreground">{t('whatsapp.lists_contacts')}</p>
              <p className="text-sm text-muted-foreground">{t('whatsapp.lists_contacts_desc')}</p>
            </div>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => navigate("/campanhas")}>
          <CardContent className="p-6 flex items-center gap-4">
            <Megaphone className="h-8 w-8 text-primary" />
            <div>
              <p className="font-medium text-foreground">{t('whatsapp.campaigns')}</p>
              <p className="text-sm text-muted-foreground">{t('whatsapp.campaigns_desc')}</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
