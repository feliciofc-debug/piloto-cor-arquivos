import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mail, Lock, ArrowLeft, Eye, EyeOff, X } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { lovable } from '@/integrations/lovable';
import { toast } from 'sonner';
import { useTranslation } from 'react-i18next';

export default function Login() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const [showForgot, setShowForgot] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [sendingReset, setSendingReset] = useState(false);
  const routedRef = useRef(false);

  const routeAfterAuth = async (userId: string, email: string) => {
    if (routedRef.current) return;
    routedRef.current = true;

    const emailLc = (email || '').trim().toLowerCase();

    // Verificar perfil do usuário
    const { data: profile } = await supabase
      .from('profiles')
      .select('tipo, validade_acesso')
      .eq('id', userId)
      .maybeSingle();

    if (profile?.validade_acesso) {
      const validade = new Date(profile.validade_acesso);
      if (validade < new Date()) {
        await supabase.auth.signOut();
        toast.error(t('login.access_expired'));
        routedRef.current = false;
        return;
      }
    }

    if (profile?.tipo === 'afiliado_admin' || profile?.tipo === 'afiliado') {
      navigate('/afiliado/dashboard');
      return;
    }

    const contasPermanentes = ['expo@atombrasildigital.com', 'renatascarega@gmail.com', 'alessandradiasadm1@gmail.com', 'dudacarega@gmail.com', 'canarimp@gmail.com'];
    if (contasPermanentes.includes(emailLc) || profile?.tipo === 'b2b' || profile?.tipo === 'parceiro' || profile?.tipo === 'empresa') {
      navigate('/dashboard');
      return;
    }

    const { data: trialCheck } = await supabase
      .from('trial_configs' as any)
      .select('status, data_fim')
      .eq('user_id', userId)
      .maybeSingle();

    if (trialCheck && (trialCheck as any).status === 'ativo' && new Date((trialCheck as any).data_fim) > new Date()) {
      navigate('/dashboard');
      return;
    }

    const { data: subscriptionCheck } = await supabase.functions.invoke('check-subscription');

    if (subscriptionCheck?.hasActiveSubscription) {
      navigate('/dashboard');
    } else {
      // Cliente novo (sem assinatura) vai direto para o checkout
      navigate('/planos');
    }
  };

  // Detecta sessão criada via Google OAuth ao voltar do provedor.
  // IMPORTANTE: só roteia quando o evento é explicitamente SIGNED_IN (login novo
  // ou retorno do OAuth), nunca em INITIAL_SESSION ou getSession() do mount,
  // pra não redirecionar sozinho quem só abriu a tela de login.
  useEffect(() => {
    const oauthFlag = 'oauth_in_progress';
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_IN' && session?.user) {
        // Só aceita como "novo login" se veio de OAuth (flag) ou de form (routedRef gerenciado no handleSubmit)
        const cameFromOAuth = sessionStorage.getItem(oauthFlag) === '1' || new URLSearchParams(window.location.search).get('oauth') === 'google';
        if (cameFromOAuth) {
          sessionStorage.removeItem(oauthFlag);
          routeAfterAuth(session.user.id, session.user.email || '');
        }
      }
    });
    return () => { sub.subscription.unsubscribe(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleGoogle = async () => {
    setGoogleLoading(true);
    try {
      sessionStorage.setItem('oauth_in_progress', '1');
      const isAmzDomain = window.location.hostname === 'amzofertas.com.br' || window.location.hostname === 'www.amzofertas.com.br';
      const redirectUri = isAmzDomain ? 'https://amzofertas.com.br/login?oauth=google' : `${window.location.origin}/login?oauth=google`;
      const oauthStartOrigin = isAmzDomain ? 'https://hello-buddy-launchpad.lovable.app' : window.location.origin;

      if (isAmzDomain) {
        const params = new URLSearchParams({
          provider: 'google',
          redirect_uri: redirectUri,
          state: crypto.randomUUID?.() || `${Date.now()}-${Math.random()}`,
        });
        window.location.href = `${oauthStartOrigin}/~oauth/initiate?${params.toString()}`;
        return;
      }

      const result = await lovable.auth.signInWithOAuth('google', {
        redirect_uri: redirectUri,
      });
      if (result.error) throw result.error;
      // Se redirected=true, browser vai redirecionar; se não, onAuthStateChange trata
    } catch (err: any) {
      toast.error(err?.message || 'Erro ao entrar com Google');
      setGoogleLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const email = formData.email.trim().toLowerCase();
      const password = formData.password;

      const { error, data } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;

      toast.success(t('login.success'));
      await routeAfterAuth(data.user.id, email);
    } catch (error: any) {
      const msg = String(error?.message || 'Erro ao fazer login');
      if (msg.toLowerCase().includes('invalid login credentials')) {
        toast.error(t('login.invalid_credentials'));
      } else {
        toast.error(msg);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendReset = async () => {
    const email = forgotEmail.trim().toLowerCase();
    if (!email) {
      toast.error(t('login.email'));
      return;
    }

    setSendingReset(true);
    try {
      const redirectTo = `${window.location.origin}/reset-password`;
      const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo });
      if (error) throw error;

      toast.success(t('login.reset_success'));
      setShowForgot(false);
    } catch (err: any) {
      toast.error(err?.message || t('login.reset_error'));
    } finally {
      setSendingReset(false);
    }
  };

  return (
    <div className="min-h-screen min-h-[100dvh] bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-start sm:items-center justify-center p-4 sm:p-6 overflow-auto">
      <div className="max-w-md w-full py-4 sm:py-0">
        {/* Botão Voltar */}
        <button 
          onClick={() => navigate('/')} 
          className="flex items-center gap-2 text-purple-300 hover:text-white mb-4 sm:mb-8 transition text-sm sm:text-base"
        >
          <ArrowLeft className="w-4 h-4 sm:w-5 sm:h-5" />
          {t('login.back_home')}
        </button>

        {/* Card Login */}
        <div className="bg-slate-800/50 backdrop-blur-lg border border-purple-500/30 rounded-2xl p-5 sm:p-8 shadow-2xl">
          {/* Logo */}
          <div className="text-center mb-5 sm:mb-8">
            <div className="bg-gradient-to-r from-orange-500 to-orange-600 p-2 sm:p-3 rounded-xl inline-block mb-3 sm:mb-4">
              <svg className="w-8 h-8 sm:w-10 sm:h-10" fill="white" viewBox="0 0 24 24">
                <path d="M20 7h-4V4c0-1.1-.9-2-2-2h-4c-1.1 0-2 .9-2 2v3H4c-1.1 0-2 .9-2 2v11c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V9c0-1.1-.9-2-2-2zM10 4h4v3h-4V4zm10 16H4V9h16v11z"/>
              </svg>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white mb-1 sm:mb-2">{t('login.title')}</h1>
            <p className="text-purple-300 text-sm sm:text-base">{t('login.subtitle')}</p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-purple-300 mb-1.5 sm:mb-2">
                {t('login.email')}
              </label>
              <div className="relative">
                <Mail className="absolute left-3 sm:left-4 top-1/2 transform -translate-y-1/2 w-4 h-4 sm:w-5 sm:h-5 text-purple-400" />
                <input
                  type="email"
                  required
                  autoComplete="email"
                  inputMode="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="w-full bg-slate-700/50 text-white text-base pl-10 sm:pl-12 pr-4 py-3 rounded-lg border border-purple-500/30 focus:outline-none focus:border-purple-500 transition placeholder:text-slate-500"
                  placeholder={t('login.email_placeholder')}
                />
              </div>
            </div>

            {/* Senha */}
            <div>
              <label className="block text-sm font-medium text-purple-300 mb-1.5 sm:mb-2">
                {t('login.password')}
              </label>
              <div className="relative">
                <Lock className="absolute left-3 sm:left-4 top-1/2 transform -translate-y-1/2 w-4 h-4 sm:w-5 sm:h-5 text-purple-400" />
                <input
                  type={showPassword ? "text" : "password"}
                  required
                  autoComplete="current-password"
                  value={formData.password}
                  onChange={(e) => setFormData({...formData, password: e.target.value})}
                  className="w-full bg-slate-700/50 text-white text-base pl-10 sm:pl-12 pr-12 py-3 rounded-lg border border-purple-500/30 focus:outline-none focus:border-purple-500 transition placeholder:text-slate-500"
                  placeholder={t('login.password_placeholder')}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 sm:right-4 top-1/2 transform -translate-y-1/2 text-purple-400 hover:text-purple-300 transition"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            {/* Esqueci Senha */}
            <div className="text-right">
              <button
                type="button"
                onClick={() => {
                  setForgotEmail(formData.email);
                  setShowForgot(true);
                }}
                className="text-sm text-purple-400 hover:text-purple-300 transition"
              >
                {t('login.forgot_password')}
              </button>
            </div>

            {/* Botão Login */}
            <div className="flex flex-col sm:grid sm:grid-cols-2 gap-3 sm:gap-4">
              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white py-3 rounded-lg font-semibold hover:shadow-lg transition disabled:opacity-50 text-base"
              >
                {isLoading ? t('login.submitting') : t('login.submit')}
              </button>
              
              <button
                type="button"
                onClick={() => navigate('/cadastro')}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-500 text-white py-3 rounded-lg font-semibold hover:shadow-lg transition text-base"
              >
                {t('login.register')}
              </button>
            </div>
          </form>

          {/* Divider */}
          <div className="relative my-5 sm:my-8">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-600"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-4 bg-slate-800 text-slate-400">{t('login.or')}</span>
            </div>
          </div>

          {/* Login com Google */}
          <button
            type="button"
            onClick={handleGoogle}
            disabled={googleLoading}
            className="w-full flex items-center justify-center gap-3 bg-white text-slate-800 py-3 rounded-lg font-semibold hover:bg-slate-100 transition disabled:opacity-50 text-base mb-5 sm:mb-6"
          >
            <svg className="w-5 h-5" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
              <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3c-1.6 4.7-6.1 8-11.3 8-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.2-.1-2.3-.4-3.5z"/>
              <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.6 15.9 18.9 13 24 13c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.4 6.3 14.7z"/>
              <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 34.7 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.6 39.6 16.2 44 24 44z"/>
              <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.2 4.3-4.1 5.7l6.2 5.2C41.4 35.4 44 30.1 44 24c0-1.2-.1-2.3-.4-3.5z"/>
            </svg>
            {googleLoading ? 'Conectando...' : 'Entrar com Google'}
          </button>


          {/* Criar Conta */}
          <div className="text-center">
            <p className="text-slate-400 mb-3 sm:mb-4 text-sm sm:text-base">{t('login.no_account')}</p>
            <button
              onClick={() => navigate('/cadastro')}
              className="w-full border-2 border-purple-500/50 text-purple-300 py-3 rounded-lg font-semibold hover:bg-purple-500/10 transition text-base"
            >
              {t('login.register_free')}
            </button>
          </div>
        </div>

        {/* Modal: Redefinir senha */}
        {showForgot && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="absolute inset-0 bg-black/60"
              onClick={() => (sendingReset ? null : setShowForgot(false))}
            />
            <div className="relative w-full max-w-md bg-slate-900 border border-purple-500/30 rounded-2xl p-6 shadow-2xl">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h2 className="text-xl font-bold text-white">{t('login.reset_title')}</h2>
                  <p className="text-purple-300 text-sm mt-1">
                    {t('login.reset_description')}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setShowForgot(false)}
                  className="text-purple-300 hover:text-white transition"
                  disabled={sendingReset}
                  aria-label="Fechar"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="mt-5">
                <label className="block text-sm font-medium text-purple-300 mb-2">{t('login.email')}</label>
                <input
                  type="email"
                  value={forgotEmail}
                  onChange={(e) => setForgotEmail(e.target.value)}
                  className="w-full bg-slate-700/50 text-white px-4 py-3 rounded-lg border border-purple-500/30 focus:outline-none focus:border-purple-500 transition placeholder:text-slate-500"
                  placeholder={t('login.email_placeholder')}
                />
              </div>

              <div className="mt-6 grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setShowForgot(false)}
                  disabled={sendingReset}
                  className="w-full border-2 border-purple-500/50 text-purple-300 py-3 rounded-lg font-semibold hover:bg-purple-500/10 transition disabled:opacity-50"
                >
                  {t('common.cancel')}
                </button>
                <button
                  type="button"
                  onClick={handleSendReset}
                  disabled={sendingReset}
                  className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white py-3 rounded-lg font-semibold hover:shadow-lg transition disabled:opacity-50"
                >
                  {sendingReset ? t('login.reset_sending') : t('login.reset_send')}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}