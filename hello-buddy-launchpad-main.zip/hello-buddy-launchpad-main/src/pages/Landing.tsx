import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { WhatsAppSupportButton } from "@/components/WhatsAppSupportButton";
import { WhatsAppFloatingButton } from "@/components/WhatsAppFloatingButton";
import FooterOptIn from "@/components/FooterOptIn";
import SiteLayout from "@/components/site/SiteLayout";

function Landing() {
  const navigate = useNavigate();

  // Scroll para o topo quando a página carregar
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Remover qualquer resquício do Typebot que possa estar em cache
  useEffect(() => {
    // Remover elementos do Typebot do DOM
    const typebotElements = document.querySelectorAll('[id*="typebot"], [class*="typebot"], typebot-bubble, typebot-standard');
    typebotElements.forEach(el => el.remove());
    
    // Limpar window.Typebot se existir
    if ((window as any).Typebot) {
      delete (window as any).Typebot;
    }
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <SiteLayout>
      <div className="bg-slate-900 text-white">
      {/* HERO SECTION */}
      <section className="pt-32 pb-20 px-6 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
                Transforme Suas Redes Sociais com <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-pink-500">Inteligência Artificial</span>
              </h2>
              <p className="text-xl text-purple-200 mb-8">
                Plataforma completa de marketing digital para pequenas e médias empresas. Crie, agende e publique conteúdo profissional em minutos.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <button
                  onClick={() => navigate('/cadastro')}
                  className="inline-flex items-center justify-center gap-2 bg-gradient-to-r from-orange-500 to-pink-500 hover:shadow-2xl text-white text-lg px-8 py-6 rounded-lg font-bold transition transform hover:scale-105"
                >
                  🚀 Fale com um Consultor
                </button>
                <a
                  href="https://wa.me/5521980804901?text=Ol%C3%A1!%20Tenho%20interesse%20em%20conhecer%20a%20AMZ%20Ofertas.%20Minha%20vitrine%20Shopee:%20"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 bg-transparent border-2 border-green-500 text-green-400 hover:bg-green-500 hover:text-white text-lg px-8 py-6 rounded-lg font-semibold transition"
                >
                  💬 Falar com Consultor
                </a>
              </div>
              <div className="flex items-center gap-8 text-sm">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">✅</span>
                  <span>Atendimento personalizado</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-2xl">✅</span>
                  <span>Configuração em 48h</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="bg-slate-800/50 backdrop-blur-lg border-2 border-purple-500/30 rounded-2xl p-8 shadow-2xl">
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-orange-300 font-semibold">Dashboard</span>
                    <span className="bg-green-500 text-xs px-3 py-1 rounded-full font-bold">ATIVO</span>
                  </div>
                  <h3 className="text-xl font-bold mb-4">Posts Agendados</h3>
                  <div className="space-y-3">
                    <div className="bg-purple-500/20 p-3 rounded-lg">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm">📱 Instagram Feed</span>
                        <span className="text-xs text-purple-300">Hoje 14h</span>
                      </div>
                      <p className="text-xs text-slate-300">Promoção especial...</p>
                    </div>
                    <div className="bg-blue-500/20 p-3 rounded-lg">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm">📘 Facebook</span>
                        <span className="text-xs text-blue-300">Amanhã 10h</span>
                      </div>
                      <p className="text-xs text-slate-300">Novidades chegando...</p>
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-pink-500/20 p-3 rounded-lg text-center">
                    <p className="text-xs text-pink-300">Posts</p>
                    <p className="text-xl font-bold">42</p>
                  </div>
                  <div className="bg-green-500/20 p-3 rounded-lg text-center">
                    <p className="text-xs text-green-300">Alcance</p>
                    <p className="text-xl font-bold">8.5k</p>
                  </div>
                  <div className="bg-orange-500/20 p-3 rounded-lg text-center">
                    <p className="text-xs text-orange-300">Engage</p>
                    <p className="text-xl font-bold">12%</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* COMO FUNCIONA */}
      <section id="como-funciona" className="py-20 px-6 bg-slate-900">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Como Funciona</h2>
            <p className="text-xl text-purple-300">3 passos simples para transformar seu marketing</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-slate-800 to-slate-900 border border-purple-500/30 rounded-2xl p-8 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-3xl font-bold mx-auto mb-6">1</div>
              <div className="text-5xl mb-4">📸</div>
              <h3 className="text-2xl font-bold mb-4">Adicione Seus Produtos</h3>
              <p className="text-slate-300">Faça upload de fotos ou cole links dos seus produtos. Nossa IA analisa e entende automaticamente.</p>
            </div>

            <div className="bg-gradient-to-br from-slate-800 to-slate-900 border border-orange-500/30 rounded-2xl p-8 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-orange-500 to-red-500 rounded-full flex items-center justify-center text-3xl font-bold mx-auto mb-6">2</div>
              <div className="text-5xl mb-4">🤖</div>
              <h3 className="text-2xl font-bold mb-4">IA Cria Conteúdo Profissional</h3>
              <p className="text-slate-300">Em segundos, receba posts otimizados para Instagram e Facebook. 3 opções de texto para cada rede social.</p>
            </div>

            <div className="bg-gradient-to-br from-slate-800 to-slate-900 border border-green-500/30 rounded-2xl p-8 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center text-3xl font-bold mx-auto mb-6">3</div>
              <div className="text-5xl mb-4">📅</div>
              <h3 className="text-2xl font-bold mb-4">Agende e Publique</h3>
              <p className="text-slate-300">Escolha datas, horários e redes. Suas postagens saem automaticamente no melhor momento.</p>
            </div>
          </div>
        </div>
      </section>

      {/* BENEFÍCIOS */}
      <section className="py-20 px-6 bg-gradient-to-b from-slate-900 to-purple-900">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Tudo Que Sua Empresa Precisa
            </h2>
            <p className="text-xl text-purple-300">Ferramentas profissionais em uma plataforma simples</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-slate-800/50 backdrop-blur-lg border border-purple-500/30 rounded-2xl p-8 hover:border-purple-500 transition">
              <div className="text-5xl mb-4">📱</div>
              <h3 className="text-2xl font-bold mb-3">Conteúdo Profissional</h3>
              <p className="text-slate-300">IA cria textos persuasivos e otimizados para cada rede social. Sempre alinhados com sua marca.</p>
            </div>

            <div className="bg-slate-800/50 backdrop-blur-lg border border-orange-500/30 rounded-2xl p-8 hover:border-orange-500 transition">
              <div className="text-5xl mb-4">📅</div>
              <h3 className="text-2xl font-bold mb-3">Agendamento Inteligente</h3>
              <p className="text-slate-300">Programe posts com antecedência. Diário, semanal ou personalizado. Sua empresa sempre presente nas redes.</p>
            </div>

            <div className="bg-slate-800/50 backdrop-blur-lg border border-green-500/30 rounded-2xl p-8 hover:border-green-500 transition">
              <div className="text-5xl mb-4">📊</div>
              <h3 className="text-2xl font-bold mb-3">Organização Total</h3>
              <p className="text-slate-300">Catálogo de produtos, biblioteca de posts e histórico completo. Tudo em um só lugar.</p>
            </div>

            <div className="bg-slate-800/50 backdrop-blur-lg border border-blue-500/30 rounded-2xl p-8 hover:border-blue-500 transition">
              <div className="text-5xl mb-4">🎯</div>
              <h3 className="text-2xl font-bold mb-3">Múltiplas Redes</h3>
              <p className="text-slate-300">Publique simultaneamente no Instagram Feed, Stories e Facebook. Economize tempo e amplie alcance.</p>
            </div>

            <div className="bg-slate-800/50 backdrop-blur-lg border border-pink-500/30 rounded-2xl p-8 hover:border-pink-500 transition">
              <div className="text-5xl mb-4">📈</div>
              <h3 className="text-2xl font-bold mb-3">Análise de Resultados</h3>
              <p className="text-slate-300">Acompanhe métricas, engajamento e desempenho. Decisões baseadas em dados reais.</p>
            </div>

            <div className="bg-slate-800/50 backdrop-blur-lg border border-yellow-500/30 rounded-2xl p-8 hover:border-yellow-500 transition">
              <div className="text-5xl mb-4">⚡</div>
              <h3 className="text-2xl font-bold mb-3">Rápido e Simples</h3>
              <p className="text-slate-300">Interface intuitiva. Sem complicação. Do produto ao post em menos de 2 minutos.</p>
            </div>
          </div>
        </div>
      </section>

      {/* PLANO */}
      <section id="planos" className="py-20 px-6 bg-slate-900">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Plano Único — Sem Complicação</h2>
            <p className="text-xl text-purple-300">Tudo que você precisa por um preço justo</p>
          </div>

          <div className="max-w-2xl mx-auto space-y-6">
            {/* Plano único R$ 597 */}
            <div className="bg-gradient-to-br from-slate-800 to-slate-900 border-2 border-orange-500 rounded-3xl p-10 shadow-2xl relative">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-orange-500 to-red-500 px-6 py-2 rounded-full text-sm font-bold">
                MAIS VENDIDO
              </div>

              <div className="text-center mb-8">
                <div className="text-6xl mb-4">🚀</div>
                <h3 className="text-3xl font-bold mb-4">AMZ OFERTAS PRO</h3>

                <div className="text-3xl font-bold text-green-400 mb-2">
                  Consulte um especialista
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4 mb-8">
                {[
                  "Publicação automática no Facebook e Instagram",
                  "IA que gera textos e imagens profissionais",
                  "Autopilot Social — posts no piloto automático",
                  "Upload de Reels e vídeos do celular",
                  "WhatsApp Marketing com campanhas",
                  "Dashboard com métricas em tempo real",
                  "Gerador de vídeo slideshow com IA",
                  "Suporte via WhatsApp",
                  "Atualizações gratuitas",
                  "Cancele quando quiser"
                ].map((feature, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <span className="text-green-400 text-xl">✅</span>
                    <span className="text-lg">{feature}</span>
                  </div>
                ))}
              </div>

              <button
                onClick={() => navigate('/cadastro')}
                className="w-full bg-gradient-to-r from-orange-500 to-pink-500 text-white py-5 rounded-xl font-bold text-2xl hover:shadow-2xl transition transform hover:scale-105 flex items-center justify-center gap-2"
              >
                🚀 Contratar Agora
              </button>

              <p className="text-center mt-4 text-sm text-slate-400">
                Prefere conversar antes?{' '}
                <a
                  href="https://wa.me/5521980804901?text=Ol%C3%A1!%20Tenho%20interesse%20em%20conhecer%20a%20AMZ%20Ofertas.%20Minha%20vitrine%20Shopee:%20"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-green-400 hover:text-green-300 font-semibold underline"
                >
                  Fale no WhatsApp
                </a>
              </p>
              <p className="text-center mt-2 text-sm text-slate-400">
                ✅ Pagamento via PIX, cartão ou boleto · Cancele quando quiser
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* DEPOIMENTOS */}
      <section className="py-20 px-6 bg-gradient-to-b from-slate-900 to-purple-900">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              O Que Nossos Clientes Dizem
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                text: "Economizamos 15 horas por semana em criação de conteúdo. A IA da AMZ é incrível!",
                name: "João Silva",
                empresa: "Padaria do Bairro",
                color: "from-purple-500 to-pink-500"
              },
              {
                text: "Triplicamos nosso engajamento no Instagram em apenas 2 meses. Resultados impressionantes!",
                name: "Maria Santos",
                empresa: "Boutique Fashion",
                color: "from-orange-500 to-red-500"
              },
              {
                text: "Plataforma completa e fácil de usar. Nossa presença digital nunca foi tão forte!",
                name: "Carlos Mendes",
                empresa: "Pet Shop Central",
                color: "from-blue-500 to-cyan-500"
              }
            ].map((testimonial, index) => (
              <div key={index} className="bg-gradient-to-br from-slate-800 to-slate-900 border border-green-500/30 rounded-2xl p-8">
                <div className="flex items-center gap-2 mb-4">
                  <span className="text-2xl">⭐⭐⭐⭐⭐</span>
                </div>
                <p className="text-lg mb-6 italic">"{testimonial.text}"</p>
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 bg-gradient-to-r ${testimonial.color} rounded-full flex items-center justify-center text-xl font-bold`}>
                    {testimonial.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-bold">{testimonial.name}</p>
                    <p className="text-sm text-slate-400">{testimonial.empresa}</p>
                    <p className="text-xs text-green-400">Cliente desde 2024</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 px-6 bg-slate-900">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Perguntas Frequentes
            </h2>
          </div>

          <Accordion type="single" collapsible className="space-y-4">
            <AccordionItem value="item-1" className="bg-slate-800/50 border border-purple-500/30 rounded-xl px-6">
              <AccordionTrigger className="text-lg font-semibold hover:text-purple-300">
                Como começo a usar a plataforma?
              </AccordionTrigger>
              <AccordionContent className="text-slate-300">
                O atendimento é consultivo: nossa equipe conversa com você no WhatsApp, entende sua operação e configura tudo pra você. Em até 48h sua automação já está rodando.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-2" className="bg-slate-800/50 border border-purple-500/30 rounded-xl px-6">
              <AccordionTrigger className="text-lg font-semibold hover:text-purple-300">
                Posso cancelar a qualquer momento?
              </AccordionTrigger>
              <AccordionContent className="text-slate-300">
                Sim! Não há fidelidade ou taxas de cancelamento. Você pode cancelar sua assinatura quando quiser através do painel de configurações.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-3" className="bg-slate-800/50 border border-purple-500/30 rounded-xl px-6">
              <AccordionTrigger className="text-lg font-semibold hover:text-purple-300">
                Quais redes sociais são suportadas?
              </AccordionTrigger>
              <AccordionContent className="text-slate-300">
                Atualmente suportamos Instagram (Feed e Stories) e Facebook. Estamos trabalhando para adicionar TikTok e LinkedIn em breve.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-4" className="bg-slate-800/50 border border-purple-500/30 rounded-xl px-6">
              <AccordionTrigger className="text-lg font-semibold hover:text-purple-300">
                A IA cria as imagens também?
              </AccordionTrigger>
              <AccordionContent className="text-slate-300">
                A IA cria textos otimizados para suas postagens. Você faz upload das fotos dos seus produtos e nossa IA gera legendas persuasivas e hashtags relevantes automaticamente.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-5" className="bg-slate-800/50 border border-purple-500/30 rounded-xl px-6">
              <AccordionTrigger className="text-lg font-semibold hover:text-purple-300">
                Preciso de conhecimento técnico?
              </AccordionTrigger>
              <AccordionContent className="text-slate-300">
                Não! A plataforma foi desenvolvida para ser extremamente intuitiva. Se você sabe usar Instagram e Facebook, já sabe usar a AMZ Ofertas. Tudo é visual e simples.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-6" className="bg-slate-800/50 border border-purple-500/30 rounded-xl px-6">
              <AccordionTrigger className="text-lg font-semibold hover:text-purple-300">
                Como funciona o agendamento?
              </AccordionTrigger>
              <AccordionContent className="text-slate-300">
                Você escolhe data, horário e em qual rede quer publicar. Pode agendar posts únicos ou criar um calendário semanal/mensal. A plataforma publica automaticamente no horário programado.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </section>

      {/* FOOTER CTA */}
      <section className="py-20 px-6 bg-gradient-to-br from-purple-900 via-slate-900 to-slate-900">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Pronto Para Transformar Suas Redes Sociais?
          </h2>
          <p className="text-xl text-purple-300 mb-8">
            Junte-se a centenas de empresas que já estão crescendo com a AMZ Ofertas
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => navigate('/cadastro')}
              className="inline-flex items-center justify-center gap-2 bg-gradient-to-r from-orange-500 to-pink-500 hover:shadow-2xl text-white text-xl px-12 py-8 rounded-lg font-bold transition transform hover:scale-105"
            >
              🚀 Contratar Agora
            </button>
            <a
              href="https://wa.me/5521980804901?text=Ol%C3%A1!%20Tenho%20interesse%20em%20conhecer%20a%20AMZ%20Ofertas.%20Minha%20vitrine%20Shopee:%20"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 bg-transparent border-2 border-green-500 text-green-400 hover:bg-green-500 hover:text-white text-xl px-12 py-8 rounded-lg font-bold transition"
            >
              💬 Falar com Consultor
            </a>
          </div>
          <p className="mt-6 text-slate-400">
            Cancele quando quiser · Configuração em 48h
          </p>
        </div>
      </section>

      {/* OPT-IN NEWSLETTER WHATSAPP */}
      <FooterOptIn />
      </div>
      <WhatsAppSupportButton />
      <WhatsAppFloatingButton />
    </SiteLayout>
  );
}

export default Landing;
