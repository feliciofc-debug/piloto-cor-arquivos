import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-route, x-billing-token',
};

const MONTHLY_AMOUNT = 597;
const GRACE_DAYS = 1;

function hasAccess(sub: any): boolean {
  if (!sub || !['active'].includes(sub.status)) return false;
  if (!sub.next_billing_date) return false;
  const due = new Date(sub.next_billing_date);
  due.setDate(due.getDate() + GRACE_DAYS);
  return new Date() <= due;
}

function clienteSituacao(sub: any) {
  if (!sub) return { key: 'sem_assinatura', label: 'Sem assinatura', inadimplente: false };
  if (sub.status === 'cancelled') return { key: 'cancelado', label: 'Cancelado', inadimplente: false };
  if (sub.status === 'pending_payment') return { key: 'pendente_pagamento', label: 'Aguardando 1º pagamento', inadimplente: false };
  if (sub.status === 'overdue') return { key: 'inadimplente', label: 'Inadimplente', inadimplente: true };
  if (sub.status === 'active') {
    if (hasAccess(sub)) return { key: 'em_dia', label: 'Em dia', inadimplente: false };
    return { key: 'inadimplente', label: 'Inadimplente', inadimplente: true };
  }
  return { key: 'desconhecido', label: sub.status || '—', inadimplente: false };
}

function pickLatest(subs: any[]) {
  if (!subs?.length) return null;
  return [...subs].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0];
}

async function verifyBillingToken(token: string): Promise<boolean> {
  const adminPassword = Deno.env.get('BILLING_ADMIN_PASSWORD');
  if (!adminPassword) return false;
  const encoder = new TextEncoder();
  const data = encoder.encode(adminPassword + ':' + Math.floor(Date.now() / (1000 * 60 * 60 * 24)));
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const expected = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return token === expected;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Auth: billing token OR admin user JWT
    let isAdmin = false;
    
    const billingToken = req.headers.get('x-billing-token') || '';
    if (billingToken) {
      isAdmin = await verifyBillingToken(billingToken);
    }

    if (!isAdmin) {
      const authBearer = req.headers.get('authorization')?.replace(/^Bearer\s+/i, '') || '';
      if (authBearer) {
        const anonClient = createClient(supabaseUrl, Deno.env.get('SUPABASE_ANON_KEY')!);
        const { data: { user } } = await anonClient.auth.getUser(authBearer);
        if (user) {
          const { data: role } = await supabase
            .from('user_roles').select('role').eq('user_id', user.id).eq('role', 'admin').maybeSingle();
          if (role) isAdmin = true;
        }
      }
    }

    if (!isAdmin) {
      return new Response(JSON.stringify({ error: 'Não autorizado' }), {
        status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const routeHeader = req.headers.get('x-route') || '';
    const url = new URL(req.url);
    const path = routeHeader || url.pathname.split('/billing-dashboard-api')[1] || '/';

    // GET /stats
    if (req.method === 'GET' && (path === '/stats' || path === '/' || path === '')) {
      const { data: rows } = await supabase.from('billing_customers').select(`
        id,
        billing_subscriptions ( id, status, next_billing_date, created_at )
      `);

      let em_dia = 0, inadimplentes = 0, pendente = 0, cancelados = 0, sem_assinatura = 0;
      for (const c of rows || []) {
        const sub = pickLatest((c as any).billing_subscriptions || []);
        const sit = clienteSituacao(sub);
        if (sit.key === 'em_dia') em_dia++;
        else if (sit.key === 'inadimplente') inadimplentes++;
        else if (sit.key === 'pendente_pagamento') pendente++;
        else if (sit.key === 'cancelado') cancelados++;
        else if (sit.key === 'sem_assinatura') sem_assinatura++;
      }

      const mrr = em_dia * MONTHLY_AMOUNT;
      return new Response(JSON.stringify({
        total_empresas: (rows || []).length,
        em_dia, inadimplentes, pendente_primeiro_pagamento: pendente, cancelados, sem_assinatura,
        mrr_estimado_reais: mrr,
        arr_estimado_reais: mrr * 12,
        valor_mensalidade: MONTHLY_AMOUNT,
      }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    // GET /clients
    if (req.method === 'GET' && path === '/clients') {
      const { data: rows } = await supabase
        .from('billing_customers')
        .select(`
          id, name, trade_name, email, phone, cnpj, cpf, tipo_pessoa, responsible_name, responsible_cpf, billing_address, platform_login, created_at,
          inscricao_estadual, inscricao_municipal, regime_tributario,
          billing_subscriptions ( id, status, next_billing_date, last_payment_date, created_at )
        `)
        .order('created_at', { ascending: false });

      const list = (rows || []).map((c: any) => {
        const sub = pickLatest(c.billing_subscriptions || []);
        const sit = clienteSituacao(sub);
        return {
          id: c.id, razao_social: c.name, trade_name: c.trade_name, email: c.email,
          phone: c.phone, cnpj: c.cnpj, cpf: c.cpf, tipo_pessoa: c.tipo_pessoa,
          responsible_name: c.responsible_name,
          next_billing_date: sub?.next_billing_date, last_payment_date: sub?.last_payment_date,
          situacao: sit.key, situacao_label: sit.label, inadimplente: sit.inadimplente,
          created_at: c.created_at,
        };
      });

      return new Response(JSON.stringify({ clients: list }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // GET /clients/:id
    if (req.method === 'GET' && path.startsWith('/clients/')) {
      const id = path.split('/clients/')[1]?.split('/')[0];
      const { data: customer } = await supabase.from('billing_customers').select('*').eq('id', id).single();
      if (!customer) {
        return new Response(JSON.stringify({ error: 'Cliente não encontrado' }), {
          status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      const { data: subscriptions } = await supabase
        .from('billing_subscriptions').select('*').eq('customer_id', id).order('created_at', { ascending: false });

      const { data: transactions } = await supabase
        .from('billing_transactions')
        .select('id, subscription_id, mp_payment_id, amount, status, payment_date, created_at')
        .eq('customer_id', id).order('created_at', { ascending: false });

      const latest = pickLatest(subscriptions || []);
      const sit = clienteSituacao(latest);

      return new Response(JSON.stringify({ customer, situacao: sit, subscriptions, transactions }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // POST /clients (create)
    if (req.method === 'POST' && path === '/clients') {
      const b = await req.json();
      const em = String(b.email || '').trim().toLowerCase();
      if (!b.razao_social?.trim() || !em) {
        return new Response(JSON.stringify({ error: 'Razão social/Nome e e-mail obrigatórios' }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      const { data: exists } = await supabase.from('billing_customers').select('id').eq('email', em).maybeSingle();
      if (exists) {
        return new Response(JSON.stringify({ error: 'E-mail já cadastrado' }), {
          status: 409, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      const digitsOnly = (s: string) => String(s || '').replace(/\D/g, '');

      const { data: customer, error: cErr } = await supabase
        .from('billing_customers')
        .insert({
          name: b.razao_social.trim(),
          trade_name: b.trade_name?.trim() || null,
          cnpj: b.cnpj ? digitsOnly(b.cnpj) : null,
          cpf: b.cpf ? digitsOnly(b.cpf) : null,
          email: em,
          phone: b.phone?.trim() || null,
          billing_address: b.billing_address || {},
          responsible_name: b.responsible_name?.trim() || null,
          responsible_cpf: b.responsible_cpf ? digitsOnly(b.responsible_cpf) : null,
          platform_login: b.platform_login?.trim() || null,
          tipo_pessoa: b.tipo_pessoa || (b.cnpj ? 'pj' : 'pf'),
          inscricao_estadual: b.inscricao_estadual?.trim() || null,
          inscricao_municipal: b.inscricao_municipal?.trim() || null,
          regime_tributario: b.regime_tributario?.trim() || null,
        })
        .select().single();

      if (cErr) throw cErr;

      const { data: subscription } = await supabase
        .from('billing_subscriptions')
        .insert({ customer_id: customer.id, status: 'pending_payment' })
        .select().single();

      return new Response(JSON.stringify({ ok: true, customer_id: customer.id, subscription_id: subscription?.id }), {
        status: 201, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // POST /clients/:id/checkout-link
    if (req.method === 'POST' && path.match(/\/clients\/[^/]+\/checkout-link/)) {
      const id = path.split('/clients/')[1]?.split('/')[0];
      const { data: customer } = await supabase.from('billing_customers').select('name, email').eq('id', id).single();
      if (!customer) {
        return new Response(JSON.stringify({ error: 'Cliente não encontrado' }), {
          status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      const { data: sub } = await supabase
        .from('billing_subscriptions').select('id').eq('customer_id', id)
        .order('created_at', { ascending: false }).limit(1).single();

      if (!sub) {
        return new Response(JSON.stringify({ error: 'Assinatura não encontrada' }), {
          status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      const mpToken = Deno.env.get('MERCADOPAGO_ACCESS_TOKEN')!;
      const notificationUrl = `${Deno.env.get('SUPABASE_URL')}/functions/v1/billing-webhook`;

      const prefResp = await fetch('https://api.mercadopago.com/checkout/preferences', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${mpToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: [{ title: `Renovação AMZOfertas — ${customer.name}`, quantity: 1, unit_price: MONTHLY_AMOUNT, currency_id: 'BRL' }],
          payer: { email: customer.email },
          external_reference: sub.id,
          notification_url: notificationUrl,
          auto_return: 'approved',
        }),
      });
      const pref = await prefResp.json();

      return new Response(JSON.stringify({ init_point: pref.init_point }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // GET /clients-by-month?ym=YYYY-MM
    if (req.method === 'GET' && path.startsWith('/clients-by-month')) {
      const qIdx = path.indexOf('?');
      const routeParams = qIdx >= 0 ? new URLSearchParams(path.slice(qIdx + 1)) : new URLSearchParams();
      const ym = routeParams.get('ym') || url.searchParams.get('ym') || new Date().toISOString().slice(0, 7);
      const [yStr, mStr] = ym.split('-');
      const y = parseInt(yStr, 10), m = parseInt(mStr, 10);
      if (!y || !m || m < 1 || m > 12) {
        return new Response(JSON.stringify({ error: 'Parâmetro ym inválido (use YYYY-MM)' }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
      const monthStart = new Date(Date.UTC(y, m - 1, 1)).toISOString();
      const monthEnd = new Date(Date.UTC(y, m, 1)).toISOString();

      const { data: customers } = await supabase
        .from('billing_customers')
        .select(`id, name, email, billing_subscriptions ( id, status, next_billing_date, last_payment_date, created_at )`)
        .order('name', { ascending: true });

      const { data: txs } = await supabase
        .from('billing_transactions')
        .select('id, customer_id, amount, status, payment_date')
        .gte('payment_date', monthStart)
        .lt('payment_date', monthEnd)
        .eq('status', 'approved');

      const txByCustomer: Record<string, any> = {};
      for (const t of txs || []) {
        if (!txByCustomer[t.customer_id]) txByCustomer[t.customer_id] = t;
      }

      const list = (customers || []).map((c: any) => {
        const sub = pickLatest(c.billing_subscriptions || []);
        const tx = txByCustomer[c.id];
        let monthStatus: 'pago' | 'pendente' | 'atrasado' = 'pendente';
        if (tx) monthStatus = 'pago';
        else if (sub?.next_billing_date) {
          // Comparar por DATA (São Paulo), não por horário.
          // Só fica "atrasado" no dia SEGUINTE ao vencimento.
          const [dy, dmo, dd] = sub.next_billing_date.split('-').map((n: string) => parseInt(n, 10));
          const dueY = dy, dueM = dmo, dueD = dd;
          const nowSP = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' }));
          const todayY = nowSP.getFullYear();
          const todayM = nowSP.getMonth() + 1;
          const todayD = nowSP.getDate();
          const dueNum = dueY * 10000 + dueM * 100 + dueD;
          const todayNum = todayY * 10000 + todayM * 100 + todayD;
          if (dueY === y && dueM === m) {
            monthStatus = todayNum > dueNum ? 'atrasado' : 'pendente';
          } else if (dueY < y || (dueY === y && dueM < m)) {
            monthStatus = 'atrasado';
          } else {
            monthStatus = 'pendente';
          }
        }
        return {
          id: c.id, razao_social: c.name, email: c.email,
          month_status: monthStatus,
          paid_amount: tx?.amount ?? null,
          paid_date: tx?.payment_date ?? null,
          next_billing_date: sub?.next_billing_date ?? null,
          subscription_id: sub?.id ?? null,
        };
      });

      const totalPago = list.filter(x => x.month_status === 'pago').reduce((s, x) => s + Number(x.paid_amount || 0), 0);
      return new Response(JSON.stringify({
        ym, clients: list,
        resumo: {
          total_clientes: list.length,
          pagos: list.filter(x => x.month_status === 'pago').length,
          pendentes: list.filter(x => x.month_status === 'pendente').length,
          atrasados: list.filter(x => x.month_status === 'atrasado').length,
          total_recebido: totalPago,
        }
      }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    // POST /clients/:id/mark-paid  body: { ym: 'YYYY-MM', amount?, payment_date? }
    if (req.method === 'POST' && path.match(/\/clients\/[^/]+\/mark-paid/)) {
      const id = path.split('/clients/')[1]?.split('/')[0];
      const body = await req.json().catch(() => ({}));
      const ym: string = body.ym || new Date().toISOString().slice(0, 7);
      const amount = Number(body.amount ?? MONTHLY_AMOUNT);
      const paymentDate = body.payment_date
        ? new Date(body.payment_date).toISOString()
        : new Date(`${ym}-15T12:00:00Z`).toISOString();

      const { data: sub } = await supabase
        .from('billing_subscriptions').select('*').eq('customer_id', id)
        .order('created_at', { ascending: false }).limit(1).single();
      if (!sub) {
        return new Response(JSON.stringify({ error: 'Assinatura não encontrada' }), {
          status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      const { error: txErr } = await supabase.from('billing_transactions').insert({
        subscription_id: sub.id,
        customer_id: id,
        mp_payment_id: `manual-${ym}-${Date.now()}`,
        amount,
        status: 'approved',
        payment_date: paymentDate,
        webhook_received: false,
        raw: { source: 'admin_manual', ym },
      });
      if (txErr) throw txErr;

      // Avança ciclo: próximo vencimento = mesmo dia do mês seguinte do ym pago
      const [yStr, mStr] = ym.split('-');
      const y = parseInt(yStr, 10), m = parseInt(mStr, 10);
      const dia = sub.dia_vencimento || (sub.next_billing_date ? new Date(sub.next_billing_date + 'T12:00:00').getUTCDate() : 15);
      const nextY = m === 12 ? y + 1 : y;
      const nextM = m === 12 ? 1 : m + 1;
      const lastDayNext = new Date(Date.UTC(nextY, nextM, 0)).getUTCDate();
      const nextDay = Math.min(dia, lastDayNext);
      const nextBilling = `${nextY}-${String(nextM).padStart(2, '0')}-${String(nextDay).padStart(2, '0')}`;
      const periodStart = `${y}-${String(m).padStart(2, '0')}-${String(Math.min(dia, new Date(Date.UTC(y, m, 0)).getUTCDate())).padStart(2, '0')}`;

      const { error: subErr } = await supabase.from('billing_subscriptions').update({
        status: 'active',
        last_payment_date: paymentDate,
        current_period_start: periodStart,
        next_billing_date: nextBilling,
        payment_fail_count: 0,
      }).eq('id', sub.id);
      if (subErr) throw subErr;

      return new Response(JSON.stringify({ ok: true, next_billing_date: nextBilling }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    return new Response(JSON.stringify({ error: 'Rota não encontrada' }), {
      status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error: any) {
    console.error('billing-dashboard-api error:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
