import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { prepareImageForInstagramSafe } from "../_shared/prepareImageForInstagram.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
}

const SAO_PAULO_TIMEZONE = 'America/Sao_Paulo'
const ADMIN_DOMAINS = ['@atombrasildigital.com']

// ---- Feature A.2: CTA de WhatsApp opt-in por produto (reutiliza lógica do inbound-processor) ----
// Busca o número do agente DO TENANT (multi-tenant) — nunca hardcodar.
async function buscarTelefoneAgenteTenant(
  supabase: any,
  userId: string,
): Promise<string | null> {
  try {
    const { data } = await supabase
      .from('whatsapp_config')
      .select('display_phone')
      .eq('user_id', userId)
      .eq('is_active', true)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle()
    const raw = (data?.display_phone || '').toString().replace(/\D/g, '')
    if (raw && raw.length >= 10) return raw
    return null
  } catch (e) {
    console.warn('[autopilot cta_whatsapp] falha buscando display_phone:', (e as Error).message)
    return null
  }
}

// Idempotente: remove qualquer CTA prévio e reaplica em SANDUÍCHE (topo + fim). Nunca triplica.
function appendWhatsappCta(script: string, phoneDigits: string): string {
  if (!script || !phoneDigits) return script
  const ctaRegex = /\s*📱\s*Fale comigo no WhatsApp:\s*wa\.me\/\d+\s*/gi
  const clean = script.replace(ctaRegex, '\n').replace(/\n{3,}/g, '\n\n').trim()
  const cta = `📱 Fale comigo no WhatsApp: wa.me/${phoneDigits}`
  return `${cta}\n\n${clean}\n\n${cta}`
}


serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
    const requestBody = req.method === 'POST' ? await req.json().catch(() => ({})) : {}
    const forceRun = requestBody?.force === true
    const configId = typeof requestBody?.config_id === 'string' ? requestBody.config_id : null

    const now = new Date()
    const nowSaoPaulo = getSaoPauloNow()
    const results: any[] = []

    console.log('🤖 [AUTOPILOT] Iniciando execução', {
      now_utc: now.toISOString(),
      now_sp: formatSaoPauloLocalIso(nowSaoPaulo),
      force_run: forceRun,
      config_id: configId,
    })

    let configQuery = supabase
      .from('autopilot_config')
      .select('*')
      .eq('ativo', true)

    if (configId) {
      configQuery = configQuery.eq('id', configId)
    }

    if (!forceRun) {
      configQuery = configQuery.or(`proxima_execucao.is.null,proxima_execucao.lte.${now.toISOString()}`)
    }

    const { data: configs, error: configError } = await configQuery

    if (configError) {
      console.error('❌ [AUTOPILOT] Erro buscando configs:', configError)
      throw new Error(`Erro buscando configs: ${configError.message}`)
    }

    console.log(`📋 [AUTOPILOT] Configs elegíveis encontradas: ${configs?.length || 0}`)

    if (!configs || configs.length === 0) {
      return new Response(JSON.stringify({
        success: true,
        message: 'Nenhum autopilot para executar',
        processed: 0,
        now_utc: now.toISOString(),
        now_sp: formatSaoPauloLocalIso(nowSaoPaulo),
        force_run: forceRun,
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      })
    }

    for (const config of configs) {
      try {
        // ============================================================
        // GATE DE INADIMPLÊNCIA — bloqueia autopilot de clientes em débito
        // Fail-open: qualquer erro permite continuar (não derruba cron)
        // ============================================================
        try {
          const { data: userData, error: userErr } = await supabase.auth.admin.getUserById(config.user_id)
          const userEmail = userData?.user?.email || ''
          const isAdmin = ADMIN_DOMAINS.some(d => userEmail.toLowerCase().endsWith(d))

          if (userErr) {
            console.warn('⚠️ [AUTOPILOT] Erro buscando user (fail-open, continuando):', userErr)
          } else if (isAdmin) {
            console.log(`✅ [AUTOPILOT] Admin bypass: ${userEmail}`)
          } else {
            // ✅ FIX: billing-validate-access espera { email } ou { platform_login }, não user_id
            const { data: billingData, error: billingErr } = await supabase.functions.invoke('billing-validate-access', {
              body: { email: userEmail, platform_login: userEmail },
            })

            if (billingErr) {
              console.warn('⚠️ [AUTOPILOT] billing-validate-access falhou (fail-open):', billingErr)
            } else if (billingData && billingData.active === false) {
              console.log('🚫 [AUTOPILOT] Cliente inadimplente, pulando', {
                config_id: config.id,
                user_id: config.user_id,
                email: userEmail,
                reason: billingData.reason || 'inadimplente',
              })
              results.push({
                config_id: config.id,
                user_id: config.user_id,
                skipped: true,
                reason: 'billing_blocked',
                billing_reason: billingData.reason,
              })
              continue
            }
          }
        } catch (gateErr) {
          console.warn('⚠️ [AUTOPILOT] Gate de inadimplência falhou (fail-open):', gateErr)
        }

        console.log('⚙️ [AUTOPILOT] Processando config', {
          config_id: config.id,
          user_id: config.user_id,
          ativo: config.ativo,
          proxima_execucao: config.proxima_execucao,
          posts_por_dia: config.posts_por_dia,
          produto_fonte: config.produto_fonte,
          categoria_filtro: config.categoria_filtro,
          ultimo_produto_index: config.ultimo_produto_index,
          total_publicados: config.total_publicados,
        })

        const diaSemana = nowSaoPaulo.getDay()
        console.log(`📅 [AUTOPILOT] Dia da semana em SP: ${diaSemana}`)

        if (!config.dias_semana?.includes(diaSemana)) {
          const proximoDia = calcularProximoDiaValido(nowSaoPaulo, config.dias_semana || [], config.horario_inicio)
          console.log('⏭️ [AUTOPILOT] Hoje não é dia válido, reagendando', {
            config_id: config.id,
            proxima_execucao_anterior: config.proxima_execucao,
            proxima_execucao_nova: proximoDia.toISOString(),
          })

          await supabase
            .from('autopilot_config')
            .update({
              proxima_execucao: proximoDia.toISOString(),
              updated_at: now.toISOString(),
            })
            .eq('id', config.id)

          results.push({
            config_id: config.id,
            skipped: true,
            reason: 'dia_semana_invalido',
            next_run: proximoDia.toISOString(),
          })
          continue
        }

        let query = supabase
          .from('produtos')
          .select('id, user_id, nome, descricao, preco, imagem_url, link, link_marketplace, categoria, ativo, usa_textos_personalizados, incluir_cta_whatsapp')
          .eq('ativo', true)
          .eq('user_id', config.user_id)
          .order('created_at', { ascending: true })
          .order('id', { ascending: true }) // 🛡️ ordem determinística (evita slice instável quando vários produtos têm o mesmo created_at)

        if (config.produto_fonte === 'categoria' && config.categoria_filtro) {
          query = query.eq('categoria', config.categoria_filtro)
        } else if (config.produto_fonte === 'manual' && config.produto_ids?.length > 0) {
          query = query.in('id', config.produto_ids)
        }

        const { data: produtos, error: prodError } = await query

        if (prodError) {
          console.error('❌ [AUTOPILOT] Erro buscando produtos:', prodError)
          throw new Error(`Erro buscando produtos: ${prodError.message}`)
        }

        console.log(`📦 [AUTOPILOT] Produtos encontrados para user ${config.user_id}: ${produtos?.length || 0}`)

        if (!produtos || produtos.length === 0) {
          results.push({
            config_id: config.id,
            skipped: true,
            reason: 'nenhum_produto_encontrado',
          })
          continue
        }

        let startIndex = config.ultimo_produto_index || 0
        if (startIndex >= produtos.length) {
          if (config.repetir_ciclo) {
            console.log(`🔁 [AUTOPILOT] Reiniciando ciclo da config ${config.id}`)
            startIndex = 0
          } else {
            console.log(`✅ [AUTOPILOT] Todos os produtos já foram postados. Desativando config ${config.id}`)
            await supabase
              .from('autopilot_config')
              .update({ ativo: false, updated_at: now.toISOString() })
              .eq('id', config.id)

            results.push({
              config_id: config.id,
              skipped: true,
              reason: 'ciclo_encerrado',
            })
            continue
          }
        }

        const postsHoje = Math.min(config.posts_por_dia, produtos.length - startIndex)
        const produtosHoje = produtos.slice(startIndex, startIndex + postsHoje)
        const horarios = calcularHorarios(config.horario_inicio, config.horario_fim, postsHoje, nowSaoPaulo)
        let postsAgendadosComSucesso = 0

        console.log('⏰ [AUTOPILOT] Horários calculados', {
          config_id: config.id,
          horarios_utc: horarios.map((horario) => horario.toISOString()),
          horarios_sp: horarios.map((horario) => formatSaoPauloIso(horario)),
        })

        for (let i = 0; i < produtosHoje.length; i++) {
          const produto = produtosHoje[i]
          const horarioPost = horarios[i]

          try {
            console.log('🧩 [AUTOPILOT] Processando produto', {
              config_id: config.id,
              user_id: config.user_id,
              produto_id: produto.id,
              produto_nome: produto.nome,
              produto_user_id: produto.user_id,
              horario_post_utc: horarioPost.toISOString(),
              horario_post_sp: formatSaoPauloIso(horarioPost),
            })

            let textoFacebook = ''
            let textoInstagram = ''
            let iaStatus = 'nao_usou'

            // === TEXTOS PERSONALIZADOS POR PRODUTO ===
            // Se o PRODUTO está em modo personalizado, usa APENAS textos próprios (sem fallback IA)
            if (produto.usa_textos_personalizados === true) {
              const { data: textosPersonalizados } = await supabase
                .from('autopilot_textos_personalizados')
                .select('texto')
                .eq('produto_id', produto.id)
                .eq('ativo', true)

              if (!textosPersonalizados || textosPersonalizados.length === 0) {
                // Sem textos: PULA + NOTIFICA cliente (zero fallback pra IA)
                console.warn('⚠️ [AUTOPILOT] Produto em modo personalizado SEM textos. Pulando.', {
                  produto_id: produto.id,
                  produto_nome: produto.nome,
                  user_id: config.user_id,
                })

                await supabase.from('notificacoes_usuario').insert({
                  user_id: config.user_id,
                  tipo: 'autopilot_sem_textos',
                  titulo: '⚠️ Produto sem textos personalizados',
                  mensagem: `O produto "${produto.nome}" está em modo personalizado mas não tem textos cadastrados. Adicione pelo menos 1 texto ou desative o modo personalizado.`,
                  produto_id: produto.id,
                })

                results.push({
                  config_id: config.id,
                  produto_id: produto.id,
                  skipped: true,
                  reason: 'modo_personalizado_sem_textos',
                })
                continue
              }

              const escolhido = textosPersonalizados[Math.floor(Math.random() * textosPersonalizados.length)]
              textoFacebook = escolhido.texto || ''
              textoInstagram = escolhido.texto || ''
              iaStatus = 'texto_personalizado_produto'
              console.log('📝 [AUTOPILOT] Usando texto personalizado do produto', {
                produto_id: produto.id,
                total_textos: textosPersonalizados.length,
              })
            }

            // === MODO ENGAJAMENTO (gera caption psicológica sem preço, link já vem na linha 1) ===
            const modoGeracao = (config as any).modo_geracao || 'padrao'
            if (!textoFacebook && modoGeracao === 'engajamento') {
              const controllerEng = new AbortController()
              const timeoutEng = setTimeout(() => controllerEng.abort(), 20000)
              try {
                console.log(`🧠 [AUTOPILOT] Modo Engajamento — chamando generate-social-post-engagement para ${produto.nome}`)
                const respEng = await fetch(`${SUPABASE_URL}/functions/v1/generate-social-post-engagement`, {
                  method: 'POST',
                  headers: {
                    'Authorization': `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
                    'Content-Type': 'application/json',
                    'apikey': SUPABASE_SERVICE_ROLE_KEY,
                  },
                  signal: controllerEng.signal,
                  body: JSON.stringify({
                    produto_id: produto.id,
                    user_id: config.user_id,
                  }),
                })
                clearTimeout(timeoutEng)

                const engData = await respEng.json().catch(() => ({} as any))
                console.log('🧠 [AUTOPILOT] Resposta engajamento', {
                  produto_id: produto.id,
                  status: respEng.status,
                  ok: respEng.ok,
                  success: engData?.success,
                  estilo: engData?.estilo,
                  fallback: engData?.fallback,
                  caracteres: engData?.caracteres,
                })

                if (engData?.success && engData?.caption) {
                  textoFacebook = engData.caption
                  textoInstagram = engData.caption
                  iaStatus = `engajamento:${engData.estilo}${engData.fallback ? ':fallback' : ''}`
                } else {
                  throw new Error(engData?.error || `engajamento_falhou_status_${respEng.status}`)
                }
              } catch (engErr) {
                clearTimeout(timeoutEng)
                iaStatus = 'engajamento_erro_fallback_padrao'
                console.error(`⚠️ [AUTOPILOT] Modo Engajamento falhou, caindo no fluxo padrão:`, engErr instanceof Error ? engErr.message : engErr)
              }
            }

            // === IA PADRÃO (quando produto NÃO está em modo personalizado E IA está ligada) ===
            if (!textoFacebook && config.gerar_texto_ia) {
              const controller = new AbortController()
              const timeout = setTimeout(() => controller.abort(), 15000)

              try {
                console.log(`✨ [AUTOPILOT] Chamando gerar-posts para ${produto.nome}`)
                const response = await fetch(`${SUPABASE_URL}/functions/v1/gerar-posts`, {
                  method: 'POST',
                  headers: {
                    'Authorization': `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
                    'Content-Type': 'application/json',
                    'apikey': SUPABASE_SERVICE_ROLE_KEY,
                  },
                  signal: controller.signal,
                  body: JSON.stringify({
                    produto: {
                      nome: produto.nome,
                      preco: produto.preco,
                      descricao: produto.descricao || '',
                    }
                  })
                })
                clearTimeout(timeout)

                const iaData = await response.json()
                console.log('📝 [AUTOPILOT] Resposta gerar-posts', {
                  produto_id: produto.id,
                  status: response.status,
                  ok: response.ok,
                  tem_posts: !!iaData?.posts,
                  erro: iaData?.error,
                })

                if (!response.ok) {
                  throw new Error(iaData?.error || `Falha HTTP ${response.status} ao gerar texto`)
                }

                if (iaData?.posts) {
                  const variacaoKey = escolherVariacao(config.estilo_texto, (config.total_publicados || 0) + i)
                  textoFacebook = iaData.posts.facebook?.[variacaoKey] || iaData.posts.facebook?.opcaoA || ''
                  textoInstagram = iaData.posts.instagram?.[variacaoKey] || iaData.posts.instagram?.opcaoA || ''
                  iaStatus = 'ok'
                }
              } catch (iaError) {
                clearTimeout(timeout)
                iaStatus = 'fallback'
                console.error(`⚠️ [AUTOPILOT] Erro/timeout IA para ${produto.nome}, usando texto padrão:`, iaError instanceof Error ? iaError.message : iaError)
              }
            }

            if (!textoFacebook) {
              textoFacebook = `🔥 ${produto.nome}\n💰 R$ ${produto.preco?.toFixed(2) || '---'}\n\nConfira essa oferta incrível!\n\n#ofertas #promocao`
            }
            if (!textoInstagram) {
              textoInstagram = textoFacebook
            }

            const linkProduto = produto.link || produto.link_marketplace || null
            // No Modo Engajamento o link já vem embutido na linha 1 da caption — não anexa de novo.
            if (modoGeracao !== 'engajamento' && config.incluir_link && linkProduto) {
              textoFacebook = `${textoFacebook}\n\n🔗 Compre aqui: ${linkProduto}`
              textoInstagram = `${textoInstagram}\n\n🔗 Link na bio ou acesse: ${linkProduto}`
            }

            // ---- Feature A.2: CTA de WhatsApp por produto (opt-in via toggle no produto) ----
            // Fail-safe: se por qualquer motivo não achar o telefone do tenant, posta SEM CTA
            // (nunca trava o autopilot por causa disso — melhor post sem CTA que autopilot parado).
            if ((produto as any).incluir_cta_whatsapp === true) {
              try {
                const telAgente = await buscarTelefoneAgenteTenant(supabase, config.user_id)
                if (telAgente) {
                  textoFacebook = appendWhatsappCta(textoFacebook, telAgente)
                  textoInstagram = appendWhatsappCta(textoInstagram, telAgente)
                  console.log('📱 [AUTOPILOT] CTA WhatsApp aplicado (sanduíche)', {
                    produto_id: produto.id,
                    user_id: config.user_id,
                    tel_len: telAgente.length,
                  })
                } else {
                  console.log('⚠️ [AUTOPILOT] Produto marcado com CTA WhatsApp, mas tenant sem display_phone ativo — postando SEM CTA (fail-safe)', {
                    produto_id: produto.id,
                    user_id: config.user_id,
                  })
                }
              } catch (ctaErr) {
                console.warn('⚠️ [AUTOPILOT] Falha ao aplicar CTA WhatsApp — postando SEM CTA:', (ctaErr as Error).message)
              }
            }




            const imagemUrl = config.incluir_imagem ? (produto.imagem_url || null) : null
            console.log('🖼️ [AUTOPILOT] Payload base do post', {
              produto_id: produto.id,
              has_image: !!imagemUrl,
              has_link: !!linkProduto,
              ia_status: iaStatus,
            })

            const { data: metaConn } = await supabase
              .from('meta_connections')
              .select('page_id, ig_account_id')
              .eq('user_id', config.user_id)
              .eq('is_active', true)
              .single()

            const clientPageId = metaConn?.page_id || ''
            const canPostFacebook = Boolean(config.postar_facebook && metaConn?.page_id)
            const canPostInstagram = Boolean(config.postar_instagram && metaConn?.ig_account_id)

            let canPostLinkedin = false
            if (config.postar_linkedin) {
              const { data: liConn } = await supabase
                .from('linkedin_connections')
                .select('id, is_active, token_expires_at')
                .eq('user_id', config.user_id)
                .maybeSingle()
              canPostLinkedin = Boolean(
                liConn?.is_active &&
                (!liConn.token_expires_at || new Date(liConn.token_expires_at).getTime() > Date.now()),
              )
            }

            console.log('🔐 [AUTOPILOT] Canais do cliente', {
              user_id: config.user_id,
              facebook: canPostFacebook,
              instagram: canPostInstagram,
              linkedin: canPostLinkedin,
              page_id: clientPageId || null,
              ig_account_id: metaConn?.ig_account_id || null,
            })

            if (!canPostFacebook && !canPostInstagram && !canPostLinkedin) {
              throw new Error('Cliente sem conexão ativa para os canais configurados')
            }

            // 🛡️ ANTI-DUPLICAÇÃO: Não agendar se o produto já tem post recente (pendente/publicado nas últimas 12h)
            // Evita o caso em que o autopilot reagenda o mesmo produto múltiplas vezes por instabilidade de ordem ou re-execução.
            const { data: postsRecentes } = await supabase
              .from('social_posts_queue')
              .select('id, platform, status, scheduled_at')
              .eq('user_id', config.user_id)
              .eq('produto_id', produto.id)
              .in('status', ['pendente', 'publicando', 'publicado'])
              .gte('scheduled_at', new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString())

            if (postsRecentes && postsRecentes.length > 0) {
              console.log('⏭️ [AUTOPILOT] Produto já tem post recente na fila/publicado, pulando para evitar duplicação', {
                produto_id: produto.id,
                produto_nome: produto.nome,
                posts_existentes: postsRecentes.map((p) => ({ id: p.id, platform: p.platform, status: p.status, scheduled_at: p.scheduled_at })),
              })
              continue
            }

            if (canPostFacebook) {
              const facebookInsert = await supabase
                .from('social_posts_queue')
                .insert({
                  user_id: config.user_id,
                  produto_id: produto.id,
                  produto_source: 'produtos',
                  platform: 'facebook',
                  page_id: clientPageId,
                  post_text: textoFacebook,
                  image_url: imagemUrl,
                  link_url: linkProduto,
                  status: 'pendente',
                  scheduled_at: horarioPost.toISOString(),
                })
                .select('id')
                .single()

              if (facebookInsert.error) {
                console.error('❌ [AUTOPILOT] Erro insert Facebook:', facebookInsert.error)
                throw new Error(`Erro ao inserir Facebook na fila: ${facebookInsert.error.message}`)
              }

              postsAgendadosComSucesso++

              console.log('📘 [AUTOPILOT] Facebook agendado com sucesso', {
                queue_id: facebookInsert.data?.id,
                produto_id: produto.id,
                horario_utc: horarioPost.toISOString(),
                horario_sp: formatSaoPauloIso(horarioPost),
              })
            } else if (config.postar_facebook) {
              console.log(`⚠️ [AUTOPILOT] Facebook pulado para ${produto.nome}: cliente sem página conectada`)
            }

            if (canPostInstagram && imagemUrl) {
              // 🛡️ Pré-processa imagem pro Instagram (AVIF→JPEG + aspect ratio)
              // Roda 1x ao agendar — evita "aspect ratio not supported" e
              // "Only photo or video can be accepted as media type" na publicação.
              let imagemUrlIg = imagemUrl
              try {
                const prep = await prepareImageForInstagramSafe(
                  imagemUrl,
                  config.user_id,
                  SUPABASE_URL,
                  SUPABASE_SERVICE_ROLE_KEY,
                )
                imagemUrlIg = prep.url
                console.log('🖼️ [AUTOPILOT] Imagem IG processada', {
                  produto_id: produto.id,
                  converted: prep.converted,
                  reason: prep.reason,
                  original_avif: imagemUrl.toLowerCase().includes('.avif'),
                })
              } catch (prepErr) {
                console.warn('⚠️ [AUTOPILOT] Falha pré-processar imagem IG, usando original:', prepErr)
              }

              const horarioIg = new Date(horarioPost.getTime() + 5 * 60 * 1000)
              const instagramInsert = await supabase
                .from('social_posts_queue')
                .insert({
                  user_id: config.user_id,
                  produto_id: produto.id,
                  produto_source: 'produtos',
                  platform: 'instagram',
                  page_id: clientPageId,
                  post_text: textoInstagram,
                  image_url: imagemUrlIg,
                  link_url: linkProduto,
                  status: 'pendente',
                  scheduled_at: horarioIg.toISOString(),
                })
                .select('id')
                .single()

              if (instagramInsert.error) {
                console.error('❌ [AUTOPILOT] Erro insert Instagram:', instagramInsert.error)
                throw new Error(`Erro ao inserir Instagram na fila: ${instagramInsert.error.message}`)
              }

              postsAgendadosComSucesso++

              console.log('📸 [AUTOPILOT] Instagram agendado com sucesso', {
                queue_id: instagramInsert.data?.id,
                produto_id: produto.id,
                horario_utc: horarioIg.toISOString(),
                horario_sp: formatSaoPauloIso(horarioIg),
              })
            } else if (config.postar_instagram && !imagemUrl) {
              console.log(`⚠️ [AUTOPILOT] Instagram pulado para ${produto.nome}: sem imagem`)
            } else if (config.postar_instagram) {
              console.log(`⚠️ [AUTOPILOT] Instagram pulado para ${produto.nome}: cliente sem Instagram conectado`)
            }

            if (canPostLinkedin) {
              const horarioLi = new Date(horarioPost.getTime() + 10 * 60 * 1000)
              const linkedinInsert = await supabase
                .from('social_posts_queue')
                .insert({
                  user_id: config.user_id,
                  produto_id: produto.id,
                  produto_source: 'produtos',
                  platform: 'linkedin',
                  post_text: textoFacebook,
                  post_text_linkedin: textoFacebook,
                  image_url: imagemUrl,
                  link_url: linkProduto,
                  status: 'pendente',
                  scheduled_at: horarioLi.toISOString(),
                })
                .select('id')
                .single()

              if (linkedinInsert.error) {
                console.error('❌ [AUTOPILOT] Erro insert LinkedIn:', linkedinInsert.error)
                throw new Error(`Erro ao inserir LinkedIn na fila: ${linkedinInsert.error.message}`)
              }

              postsAgendadosComSucesso++

              console.log('💼 [AUTOPILOT] LinkedIn agendado com sucesso', {
                queue_id: linkedinInsert.data?.id,
                produto_id: produto.id,
                horario_utc: horarioLi.toISOString(),
                horario_sp: formatSaoPauloIso(horarioLi),
              })
            } else if (config.postar_linkedin) {
              console.log(`⚠️ [AUTOPILOT] LinkedIn pulado para ${produto.nome}: cliente sem LinkedIn conectado`)
            }
          } catch (produtoError) {
            const errMsg = produtoError instanceof Error ? produtoError.message : 'Erro desconhecido'
            console.error(`❌ [AUTOPILOT] Erro no produto ${produto.nome} (${produto.id}), CONTINUANDO com próximo produto:`, errMsg)
            continue
          }
        }

        // ============================================================
        // 🎥 BLOCO NOVO: AUTOPILOT DE VÍDEOS (REELS)
        // Agenda vídeos do usuário na tabela videos_agendados como reels.
        // Só roda se config.postar_videos = true e usuário tiver vídeos.
        // ============================================================
        let videosAgendadosHoje = 0
        let novoVideoIndex = config.ultimo_video_index || 0

        if ((config as any).postar_videos === true) {
          try {
            const { data: videosDisponiveis } = await supabase
              .from('videos_produtos')
              .select('id, user_id, titulo, descricao, video_url, produto_id')
              .eq('user_id', config.user_id)
              .eq('status', 'disponivel')
              .order('created_at', { ascending: true })
              .order('id', { ascending: true })

            console.log(`🎥 [AUTOPILOT VIDEOS] Vídeos encontrados: ${videosDisponiveis?.length || 0}`)

            if (videosDisponiveis && videosDisponiveis.length > 0) {
              let vStart = config.ultimo_video_index || 0
              if (vStart >= videosDisponiveis.length) {
                if (config.repetir_ciclo) {
                  console.log('🔁 [AUTOPILOT VIDEOS] Reiniciando ciclo de vídeos')
                  vStart = 0
                } else {
                  console.log('✅ [AUTOPILOT VIDEOS] Todos os vídeos já foram postados; pulando bloco de vídeos')
                  vStart = -1
                }
              }

              if (vStart >= 0) {
                const videosQtd = Math.min((config as any).videos_por_dia || 1, videosDisponiveis.length - vStart)
                const videosHoje = videosDisponiveis.slice(vStart, vStart + videosQtd)
                const horariosVideos = calcularHorarios(config.horario_inicio, config.horario_fim, videosQtd, nowSaoPaulo)

                const canais: string[] = []
                if (config.postar_facebook) canais.push('facebook')
                if (config.postar_instagram) canais.push('instagram')

                if (canais.length === 0) {
                  console.log('⚠️ [AUTOPILOT VIDEOS] Nenhum canal habilitado — pulando vídeos')
                } else {
                  for (let vi = 0; vi < videosHoje.length; vi++) {
                    const video = videosHoje[vi]
                    const horarioVid = horariosVideos[vi]

                    try {
                      // Anti-duplicação: pular se este vídeo já foi agendado/publicado nas últimas 12h
                      const { data: agendadosRecentes } = await supabase
                        .from('videos_agendados')
                        .select('id, status')
                        .eq('user_id', config.user_id)
                        .eq('video_url', video.video_url)
                        .in('status', ['pendente', 'processando', 'publicado'])
                        .gte('scheduled_for', new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString())

                      if (agendadosRecentes && agendadosRecentes.length > 0) {
                        console.log('⏭️ [AUTOPILOT VIDEOS] Vídeo já agendado recentemente, pulando', { video_id: video.id })
                        continue
                      }

                      // Caption: usa descrição/título; tenta IA se ligada
                      let caption = video.descricao || video.titulo || ''
                      if (!caption && config.gerar_texto_ia && video.produto_id) {
                        try {
                          const controllerV = new AbortController()
                          const timeoutV = setTimeout(() => controllerV.abort(), 12000)
                          const respV = await fetch(`${SUPABASE_URL}/functions/v1/gerar-posts`, {
                            method: 'POST',
                            headers: {
                              'Authorization': `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
                              'Content-Type': 'application/json',
                              'apikey': SUPABASE_SERVICE_ROLE_KEY,
                            },
                            signal: controllerV.signal,
                            body: JSON.stringify({ produto_id: video.produto_id, user_id: config.user_id }),
                          })
                          clearTimeout(timeoutV)
                          const dataV = await respV.json().catch(() => ({} as any))
                          caption = dataV?.posts?.instagram?.opcaoA || dataV?.posts?.facebook?.opcaoA || caption
                        } catch (capErr) {
                          console.warn('⚠️ [AUTOPILOT VIDEOS] IA caption falhou, usando fallback:', (capErr as Error).message)
                        }
                      }
                      if (!caption) {
                        caption = video.titulo || 'Confira esse vídeo! 🎬'
                      }

                      const { error: vidErr } = await supabase
                        .from('videos_agendados')
                        .insert({
                          user_id: config.user_id,
                          tipo: 'reels',
                          video_url: video.video_url,
                          video_nome: video.titulo,
                          caption,
                          canais,
                          produto_id: video.produto_id || null,
                          scheduled_for: horarioVid.toISOString(),
                          status: 'pendente',
                          tentativas: 0,
                          metadata: { source: 'autopilot', autopilot_config_id: config.id },
                        })

                      if (vidErr) {
                        console.error('❌ [AUTOPILOT VIDEOS] Erro insert reels:', vidErr)
                      } else {
                        videosAgendadosHoje++
                        console.log('🎬 [AUTOPILOT VIDEOS] Reels agendado', {
                          video_id: video.id,
                          canais,
                          horario_sp: formatSaoPauloIso(horarioVid),
                        })
                      }
                    } catch (vErr) {
                      console.error('❌ [AUTOPILOT VIDEOS] Erro no vídeo, continuando:', (vErr as Error).message)
                      continue
                    }
                  }
                  novoVideoIndex = vStart + videosQtd
                }
              }
            }
          } catch (videosErr) {
            console.error('❌ [AUTOPILOT VIDEOS] Erro no bloco de vídeos (fail-open):', (videosErr as Error).message)
          }
        }

        const novoIndex = startIndex + postsHoje
        const proximaExecucao = calcularProximoDiaValido(nowSaoPaulo, config.dias_semana || [], config.horario_inicio)

        const updateResult = await supabase
          .from('autopilot_config')
          .update({
            ultimo_produto_index: novoIndex,
            ultimo_video_index: novoVideoIndex,
            ultima_execucao: now.toISOString(),
            proxima_execucao: proximaExecucao.toISOString(),
            total_publicados: (config.total_publicados || 0) + postsHoje + videosAgendadosHoje,
            updated_at: now.toISOString(),
          })
          .eq('id', config.id)


        if (updateResult.error) {
          console.error('❌ [AUTOPILOT] Erro atualizando config:', updateResult.error)
          throw new Error(`Erro atualizando config: ${updateResult.error.message}`)
        }

        results.push({
          config_id: config.id,
          user_id: config.user_id,
          produtos_agendados: postsHoje,
          proximo_index: novoIndex,
          proxima_execucao: proximaExecucao.toISOString(),
          proxima_execucao_sp: formatSaoPauloIso(proximaExecucao),
        })

        console.log(`✅ [AUTOPILOT] Config ${config.id} concluída: ${postsAgendadosComSucesso} posts agendados de ${postsHoje} produtos`)
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : 'Erro desconhecido'
        console.error(`❌ [AUTOPILOT] Erro na config ${config.id}:`, errorMsg)
        results.push({ config_id: config.id, error: errorMsg })
      }
    }

    return new Response(JSON.stringify({
      success: true,
      timestamp: now.toISOString(),
      processed: results.length,
      results
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  } catch (error) {
    console.error('❌ [AUTOPILOT] Erro geral:', error)
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : 'Erro desconhecido'
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }
})

function calcularHorarios(inicio: string, fim: string, quantidade: number, agoraSaoPaulo: Date): Date[] {
  const [hInicio, mInicio] = inicio.split(':').map(Number)
  const [hFim, mFim] = fim.split(':').map(Number)
  const inicioMin = hInicio * 60 + mInicio
  const fimMin = hFim * 60 + mFim
  const horarios: Date[] = []

  if (quantidade <= 0) return horarios

  const agoraMin = agoraSaoPaulo.getHours() * 60 + agoraSaoPaulo.getMinutes()
  const primeiroHorarioMin = Math.max(inicioMin, agoraMin + 5)

  // Se a janela do dia praticamente acabou, mantém o disparo ainda hoje
  // em cadência curta, em vez de empurrar tudo para amanhã.
  if (primeiroHorarioMin >= fimMin) {
    for (let i = 0; i < quantidade; i++) {
      const minutos = primeiroHorarioMin + (i * 10)
      const d = createUtcDateFromSaoPaulo(agoraSaoPaulo, Math.floor(minutos / 60), minutos % 60)
      ajustarHorarioSePassou(d, agoraSaoPaulo)
      horarios.push(d)
    }
    return horarios
  }

  if (quantidade === 1) {
    const d = createUtcDateFromSaoPaulo(agoraSaoPaulo, Math.floor(primeiroHorarioMin / 60), primeiroHorarioMin % 60)
    ajustarHorarioSePassou(d, agoraSaoPaulo)
    horarios.push(d)
    return horarios
  }

  const janelaRestanteMin = Math.max(fimMin - primeiroHorarioMin, 1)
  const intervaloMin = Math.max(Math.floor(janelaRestanteMin / quantidade), 10)

  for (let i = 0; i < quantidade; i++) {
    const minutos = primeiroHorarioMin + (intervaloMin * i)
    const d = createUtcDateFromSaoPaulo(agoraSaoPaulo, Math.floor(minutos / 60), minutos % 60)
    ajustarHorarioSePassou(d, agoraSaoPaulo)
    horarios.push(d)
  }

  return horarios
}

function ajustarHorarioSePassou(dataUtc: Date, agoraSaoPaulo: Date) {
  const agoraUtc = saoPauloLocalToUtc(agoraSaoPaulo)
  if (dataUtc <= agoraUtc) {
    // Se o horário já passou HOJE, agendar pra daqui 5-15 minutos
    // NÃO pular pro dia seguinte
    const novosMs = agoraUtc.getTime() + (Math.floor(Math.random() * 10) + 5) * 60 * 1000
    dataUtc.setTime(novosMs)
  }
}

function calcularProximoDiaValido(agoraSaoPaulo: Date, diasSemana: number[], horarioInicio: string): Date {
  const [h, m] = horarioInicio.split(':').map(Number)

  // Tenta primeiro rodar HOJE no horário de início, se ainda não passou e hoje for dia válido
  const hoje = new Date(agoraSaoPaulo)
  hoje.setHours(h, m, 0, 0)
  const aindaHaJanelaHoje = hoje > agoraSaoPaulo
  if (aindaHaJanelaHoje && diasSemana.includes(hoje.getDay())) {
    return saoPauloLocalToUtc(hoje)
  }

  // Caso contrário, procura o próximo dia válido (a partir de amanhã)
  const proximo = new Date(agoraSaoPaulo)
  proximo.setDate(proximo.getDate() + 1)
  proximo.setHours(h, m, 0, 0)

  for (let i = 0; i < 7; i++) {
    if (diasSemana.includes(proximo.getDay())) {
      return saoPauloLocalToUtc(proximo)
    }
    proximo.setDate(proximo.getDate() + 1)
  }

  return saoPauloLocalToUtc(proximo)
}

function createUtcDateFromSaoPaulo(baseSaoPaulo: Date, hours: number, minutes: number) {
  const localDate = new Date(baseSaoPaulo)
  localDate.setHours(hours, minutes, 0, 0)
  return saoPauloLocalToUtc(localDate)
}

function getSaoPauloNow() {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: SAO_PAULO_TIMEZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  }).formatToParts(new Date())

  const readPart = (type: string) => Number(parts.find((part) => part.type === type)?.value || 0)

  return new Date(
    readPart('year'),
    readPart('month') - 1,
    readPart('day'),
    readPart('hour'),
    readPart('minute'),
    readPart('second'),
    0,
  )
}

function saoPauloLocalToUtc(localDate: Date) {
  return new Date(Date.UTC(
    localDate.getFullYear(),
    localDate.getMonth(),
    localDate.getDate(),
    localDate.getHours() + 3,
    localDate.getMinutes(),
    localDate.getSeconds(),
    localDate.getMilliseconds(),
  ))
}

function formatSaoPauloIso(date: Date) {
  return date.toLocaleString('sv-SE', {
    timeZone: SAO_PAULO_TIMEZONE,
    hour12: false,
  }).replace(' ', 'T')
}

function formatSaoPauloLocalIso(date: Date) {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  const hours = String(date.getHours()).padStart(2, '0')
  const minutes = String(date.getMinutes()).padStart(2, '0')
  const seconds = String(date.getSeconds()).padStart(2, '0')
  return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`
}

function escolherVariacao(estilo: string, index: number): string {
  if (estilo === 'casual') return 'opcaoA'
  if (estilo === 'informativo') return 'opcaoB'
  if (estilo === 'urgente') return 'opcaoC'
  const variacoes = ['opcaoA', 'opcaoB', 'opcaoC']
  return variacoes[index % 3]
}
