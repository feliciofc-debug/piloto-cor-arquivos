// ============================================================
// ESTILO DE COPY POR TENANT (multi-tenant, isolado por user_id)
//
// voz_copy = 'empresa' → 1ª pessoa do PLURAL (padrão, comportamento antigo)
// voz_copy = 'pessoa'  → 1ª pessoa do SINGULAR ("me chama", "eu te ajudo"),
//                        assinando com nome_assinatura.
//
// Link de atendimento: empresa_config.link_post; se vazio, o wa.me montado a
// partir do whatsapp_config.display_phone DO PRÓPRIO user_id.
// NUNCA número/constante fixa no código.
// ============================================================

export type VozCopy = "empresa" | "pessoa";

export type CopyStyle = {
  voz: VozCopy;
  assinatura: string | null;
  /** link de atendimento do tenant (https://wa.me/... ou link_post salvo) */
  link: string | null;
  /** regras de tom/conteúdo específicas do tenant (empresa_config.regras_copy) */
  regras: string | null;
  /** template de copy COMPARTILHADO do segmento (rede), já com variáveis trocadas */
  template: string | null;
  /** quando true, a copy leva assinatura "— Nome" no fim */
  assinar: boolean;
  /** bloco pronto para injetar no prompt da IA */
  promptBlock: string;
};

export const COPY_STYLE_PADRAO: CopyStyle = {
  voz: "empresa",
  assinatura: null,
  link: null,
  regras: null,
  template: null,
  assinar: false,
  promptBlock: "",
};

/** Extrai o user_id (sub) do JWT do request, sem chamada de rede. */
export function userIdDoRequest(req: Request): string | null {
  try {
    const auth = req.headers.get("Authorization") || "";
    const token = auth.replace(/^Bearer\s+/i, "").trim();
    const parte = token.split(".")[1];
    if (!parte) return null;
    const json = JSON.parse(
      atob(parte.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((parte.length + 3) % 4)),
    );
    const sub = String(json?.sub || "").trim();
    return /^[0-9a-f-]{36}$/i.test(sub) ? sub : null;
  } catch {
    return null;
  }
}

/** Troca as variáveis do template compartilhado pelos valores DESTE tenant. */
export function renderCopyTemplate(
  tpl: string,
  vars: { link: string | null; assinatura: string | null },
): string {
  return tpl
    .replace(/\{\{\s*LINK\s*\}\}/g, vars.link || "")
    .replace(/\{\{\s*ASSINATURA\s*\}\}/g, vars.assinatura || "")
    .replace(/\{\{\s*NOME_CONSULTOR\s*\}\}/g, vars.assinatura || "");
}

function montarPromptBlock(
  voz: VozCopy,
  assinatura: string | null,
  link: string | null,
  regras: string | null,
  template: string | null,
): string {
  // Template COMPARTILHADO do segmento: substitui as regras genéricas de voz.
  if (template && template.trim()) {
    const bloco: string[] = ["", template.trim()];
    if (regras && regras.trim()) {
      bloco.push(
        "",
        "=== AJUSTES DESTE CONSULTOR (complementam o padrão da rede) ===",
        regras.trim(),
      );
    }
    bloco.push("");
    return bloco.join("\n");
  }

  const linhas: string[] = ["", "=== VOZ E FORMATO DA COPY (OBRIGATÓRIO) ==="];

  if (voz === "pessoa") {
    linhas.push(
      "- Escreva em PRIMEIRA PESSOA DO SINGULAR, como um consultor falando com o cliente, sem vitrine.",
      '- É PROIBIDO usar plural de empresa: "nós", "nossa equipe", "fale com a gente", "ajudamos você", "aqui na <empresa>".',
      "- NÃO assine a copy com nome de pessoa nem de empresa.",
    );
  } else {
    linhas.push(
      "- Escreva em primeira pessoa do PLURAL, como empresa (\"nossa equipe\", \"fale com a gente\").",
    );
  }

  if (link) {
    linhas.push(
      `- A PRIMEIRA LINHA da copy é o link, sozinho, sem frase de chamada: ${link}`,
      "- O link tem que estar nos primeiros ~120 caracteres (o Instagram corta a legenda com \"... mais\").",
      "- Nunca deixe o link só no fim do texto e nunca escreva \"clica no link\" / \"me chama\".",
    );
  }

  linhas.push(
    "- Ordem da copy: 1) link sozinho na primeira linha, 2) corpo que termina no raciocínio (sem convite/CTA no fim), 3) hashtags.",
    "- LINGUAGEM SIMPLES, NÃO FORMAL: proibido tom de relatório bancário. Diga \"comprar\" em vez de \"estruturar a aquisição\", \"apertar o orçamento\" em vez de \"desequilibrar as finanças\", \"não mexer na reserva\" em vez de \"preservar a liquidez\", \"comprar melhor\" em vez de \"potencializar o poder de compra\", \"parcelas\" em vez de \"aportes programados\", \"juntar dinheiro\" em vez de \"formação de capital\", \"crescer\" em vez de \"expansão patrimonial\", \"custo que compensa\" em vez de \"custo eficiente\", \"explicar\" em vez de \"desmistificar\", \"construir patrimônio\" em vez de \"consolidar patrimônio\".",
    "- Frases curtas, uma ideia por frase, 2 a 3 frases no total. Nunca duas palavras técnicas na mesma frase.",
    "- Comece pela situação concreta do leitor (gente comprando coisa), não pelo conceito.",
    "- QUEM ESCREVE NÃO APARECE NA FRASE: proibido \"quero te ajudar\", \"falo sobre\", \"explico\", \"meu foco é\", \"posso te mostrar\", \"trabalho com\", \"vale olhar\". A copy é observação sobre o ASSUNTO, não apresentação de serviço. Errado: \"Explico as possibilidades dessa ferramenta.\" Certo: \"Existe uma diferença entre comprar rápido e comprar bem.\"",
    "- O último período fecha com a consequência prática do que foi dito, nunca com convite, promessa ou frase vaga tipo \"chegar lá com tranquilidade\". Ex: \"No fim, o que muda não é o valor da parcela. É o que sobra depois.\"",
    "- Consórcio NÃO é crédito e NÃO é investimento: proibido \"crédito com custo mais baixo\", \"crédito barato\", ou qualquer sugestão de rendimento/rentabilidade (produto regulado pelo Banco Central).",
    "- 3 hashtags (máximo 4), simples e reais (#Consórcio #Ademicon + uma do tema). PROIBIDAS: #Investimento, #Renda, #Rentabilidade, #Crédito, #Juros, #Financiamento e termos inventados tipo #GestãoDeAtivos.",
  );



  if (regras && regras.trim()) {
    linhas.push(
      "",
      "=== REGRAS DE TOM E CONTEÚDO DESTE CLIENTE (PRIORIDADE MÁXIMA) ===",
      regras.trim(),
      "Estas regras se sobrepõem a qualquer instrução genérica de copy acima.",
    );
  }

  linhas.push("");
  return linhas.join("\n");
}

export async function getCopyStyle(sb: any, userId: string | null | undefined): Promise<CopyStyle> {
  if (!userId) return COPY_STYLE_PADRAO;

  let voz: VozCopy = "empresa";
  let assinatura: string | null = null;
  let link: string | null = null;
  let regras: string | null = null;

  try {
    const { data } = await sb
      .from("empresa_config")
      .select("voz_copy, nome_assinatura, link_post, regras_copy")
      .eq("user_id", userId)
      .maybeSingle();

    if (data) {
      voz = data.voz_copy === "pessoa" ? "pessoa" : "empresa";
      assinatura = (data.nome_assinatura || "").trim() || null;
      regras = (data.regras_copy || "").trim() || null;
      const lp = (data.link_post || "").trim();
      if (/^https?:\/\//i.test(lp)) link = lp;
    }
  } catch (e) {
    console.warn("⚠️ getCopyStyle: empresa_config indisponível:", (e as Error).message);
  }

  let template: string | null = null;
  try {
    const { data: agent } = await sb
      .from("whatsapp_cloud_agent_config")
      .select("knowledge_segment_id, nome_consultor")
      .eq("user_id", userId)
      .maybeSingle();

    if (!assinatura && agent?.nome_consultor) assinatura = String(agent.nome_consultor).trim() || null;

    if (agent?.knowledge_segment_id) {
      const { data: seg } = await sb
        .from("agent_knowledge_segments")
        .select("copy_template")
        .eq("id", agent.knowledge_segment_id)
        .maybeSingle();
      const t = (seg?.copy_template || "").trim();
      if (t) template = t;
    }
  } catch (e) {
    console.warn("⚠️ getCopyStyle: template de segmento indisponível:", (e as Error).message);
  }

  if (!link) {
    try {
      const { data } = await sb
        .from("whatsapp_config")
        .select("display_phone")
        .eq("user_id", userId)
        .maybeSingle();
      const digits = String(data?.display_phone || "").replace(/\D/g, "");
      if (digits.length >= 10) link = `https://wa.me/${digits}`;
    } catch (e) {
      console.warn("⚠️ getCopyStyle: whatsapp_config indisponível:", (e as Error).message);
    }
  }

  if (template) template = renderCopyTemplate(template, { link, assinatura });

  return {
    voz,
    assinatura,
    link,
    regras,
    template,
    assinar: Boolean(template && assinatura),
    promptBlock: montarPromptBlock(voz, assinatura, link, regras, template),
  };
}

/**
 * Garante o link no INÍCIO da legenda e a assinatura pessoal no fim.
 * Idempotente: se o link/assinatura já estiverem no texto, não duplica.
 */
export function aplicarEstiloCopy(texto: string | null | undefined, style: CopyStyle): string {
  let base = (texto || "").trim();
  if (!base) return style.link || "";

  if (style.link && !base.includes(style.link)) {
    // Link sozinho na primeira linha — sem frase de chamada/CTA.
    base = `${style.link}\n\n${base}`;
  }


  // Assinatura só quando o template compartilhado da rede pede (ex: Ademicon).
  if (style.assinar && style.assinatura) {
    const assin = `— ${style.assinatura}`;
    if (!base.includes(assin) && !base.includes(style.assinatura)) {
      const linhas = base.split("\n");
      const iHash = linhas.findIndex((l) => /^\s*#\S/.test(l));
      if (iHash > 0) {
        linhas.splice(iHash, 0, assin, "");
        base = linhas.join("\n").replace(/\n{3,}/g, "\n\n");
      } else {
        base = `${base}\n\n${assin}`;
      }
    }
  }

  return base;
}
